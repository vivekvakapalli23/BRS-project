# BookVerse AI - Ontology-Based Intelligent Book Recommendation System

> **BookVerse AI** is a production-grade, full-stack Django enterprise platform for intelligent book discovery. It integrates **W3C OWL 2 Knowledge Ontologies (RDFLib)**, **Machine Learning Hybrid Recommendation Engines (TF-IDF + Collaborative Filtering + KNN)**, **Interactive Knowledge Graphs (Cytoscape.js)**, **Online Digital Reading (PDF / EPUB / Formatted Chapter Reader)**, **Personalized User Dashboards**, and a **Custom Admin Command Center**.

---

## 🌟 Key Features

1. **AI / ML Multi-Signal Hybrid Recommender**
   - **TF-IDF Content Filtering**: Computes cosine similarities across book titles, descriptions, genres, authors, and thematic subject vectors.
   - **Collaborative Filtering (KNN)**: Sparse user-item rating matrix with cosine nearest-neighbor similarity.
   - **OWL Semantic Reasoning**: Deep path-scoring traversing `writtenBy`, `hasGenre`, `publishedBy`, and `similarTo` triples in RDFLib.
   - **Explainable AI (XAI)**: Explicit explanation badges breaking down the match rationale for every recommendation.
   - **Cold-Start Matching**: Smooth onboarding matching selected user genre affinities and community acclaim.
   - **Feedback Learning Loop**: Instant like, dislike, save, and not-interested signals to tune future rankings.

2. **Semantic Ontology Knowledge Graph**
   - Formal OWL classes: `Book`, `Author`, `Genre`, `Subject`, `Publisher`, `Language`, `User`, `Interest`, `Rating`, `Review`, `ReadingHistory`.
   - Object properties: `writtenBy`, `hasGenre`, `hasSubject`, `publishedBy`, `hasLanguage`, `interestedIn`, `hasRead`, `likesBook`, `ratedBook`, `similarTo`.
   - Dynamic OWL XML (`.owl`) and Turtle (`.ttl`) export and synchronization.
   - Interactive visual graph explorer powered by **Cytoscape.js** with real-time node inspection.

3. **Conversational AI Book Assistant**
   - Natural language book discovery and semantic keyword retrieval.
   - Creates personalized 4-week structured reading plans with daily page pace targets.
   - Answers bibliographic queries without requiring third-party paid API keys.

4. **Online Reader & Digital Library**
   - Supports authorized PDF and EPUB reading.
   - Distraction-free chapter reader with Day, Sepia, and Night themes.
   - Dynamic font resizing (A- / A+).
   - Real-time reading progress persistence (page, percentage, CFI) to Django.
   - Interactive bookmarking with reflection notes.
   - Reading streak tracking and reading goal progress.

5. **Executive Custom Admin Panel**
   - Real-time KPI summary cards (Total Books, Registered Readers, Active Readers, Monthly Growth, Average Rating, ML Status).
   - Interactive Chart.js analytics (Registrations, Popular Genres, Most Read Books, Rating Distributions).
   - Complete CRUD operations for Books, Authors, Genres, and Users.
   - 1-Click Open Library API metadata importer.
   - Bulk CSV catalog ingestion.
   - In-dashboard ML model training and ontology rebuilding.

---

## 🛠️ Tech Stack

- **Backend**: Python 3.14+, Django 6.1+, Django REST Framework
- **Machine Learning & Math**: scikit-learn, pandas, numpy, scipy
- **Semantic Web & Ontologies**: RDFLib 7.6+, Owlready2
- **Frontend & UI**: HTML5, CSS3, JavaScript, Bootstrap 5.3, Bootstrap Icons
- **Visualizations**: Chart.js, Cytoscape.js
- **Database**: SQLite3 (zero-configuration development)

---

## 🚀 Quickstart Guide (Windows PowerShell)

Open PowerShell and navigate to the project directory:

```powershell
cd "d:\Book recommendation system\book_recommendation_system"
```

### 1. Create and Activate Virtual Environment
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

### 2. Install Dependencies
```powershell
pip install -r requirements.txt
```

### 3. Apply Database Migrations
```powershell
python manage.py migrate
```

### 4. Seed Database with Realistic Demonstration Data
Populates authors, genres, books with synopsis & chapters, reviews, users, builds the OWL ontology, and trains the recommendation model:
```powershell
python manage.py seed_data
```

### 5. Evaluate Recommendation Quality (Offline Metrics)
```powershell
python manage.py evaluate_recommendations --k 5
```

### 6. Run Automated Test Suite
```powershell
python manage.py test tests
```

### 7. Start Django Development Server
```powershell
python manage.py runserver
```
Visit the application in your browser at: **`http://127.0.0.1:8000/`**

---

## 👥 Demo User Credentials

| Role | Username | Password | Notes |
|---|---|---|---|
| **Superuser / Staff Admin** | `admin` | `admin123` | Full access to Custom Admin Panel (`/admin-panel/`) and Django Admin (`/django-admin/`) |
| **Reader (Sci-Fi & AI Enthusiast)** | `alice` | `password123` | Active reading streak, favorites, custom goals |
| **Reader (Classical Literature)** | `bob` | `password123` | History and philosophy lover |
| **Reader (Mystery & Noir)** | `charlie` | `password123` | Investigative mystery reader |
| **Reader (Psychology & Science)** | `diana` | `password123` | High engagement reader |

---

## 📂 Project Architecture

```
book_recommendation_system/
├── manage.py
├── requirements.txt
├── .env.example
├── README.md
├── config/                  # Django project root settings and URL routing
├── accounts/                # Authentication, UserProfile, Streaks, Avatars
├── books/                   # Books, Authors, Genres, ReadingProgress, Open Library API
├── recommendations/         # TF-IDF, KNN, Hybrid Recommender Engine, Model Versions
├── ontology/                # W3C OWL/RDF schema, Cytoscape graph API, generator
├── dashboard/               # Personalized reader dashboard & analytics
├── custom_admin/            # Custom administrative dashboard, CRUD, CSV/API imports
├── reader/                  # Online reading engine (PDF/EPUB/Text), Bookmarks, Shelves
├── assistant/               # Conversational AI assistant with local semantic search
├── analytics/               # Reading telemetry, Chart.js visualizations
├── community/               # Reviews, Star ratings, Discussions, Moderation, Following
├── notifications/           # Notification center & contextual alert badges
├── templates/               # Premium responsive Bootstrap 5 templates
├── static/                  # Custom CSS design system and JavaScript utilities
├── media/                   # Uploaded covers, avatars, and reader files
└── tests/                   # Full end-to-end unit and integration test suite
```

---

## 📜 License
Developed for academic, research, and enterprise digital library deployment. Built with ❤️ by BookVerse AI.
