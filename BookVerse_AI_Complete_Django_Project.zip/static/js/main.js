// BookVerse AI - Main JavaScript Utilities

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

const csrftoken = getCookie('csrftoken');

// Toast alert helper
function showToast(message, type = 'primary') {
    const toastContainer = document.getElementById('toast-container');
    if (!toastContainer) return;
    const toastEl = document.createElement('div');
    toastEl.className = `toast align-items-center text-bg-${type} border-0 mb-2`;
    toastEl.setAttribute('role', 'alert');
    toastEl.setAttribute('aria-live', 'assertive');
    toastEl.setAttribute('aria-atomic', 'true');
    toastEl.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${message}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    toastContainer.appendChild(toastEl);
    const toast = new bootstrap.Toast(toastEl, { delay: 3500 });
    toast.show();
    toastEl.addEventListener('hidden.bs.toast', () => toastEl.remove());
}

// Dark Mode Toggle
document.addEventListener('DOMContentLoaded', () => {
    const darkToggleBtn = document.getElementById('dark-mode-toggle');
    if (darkToggleBtn) {
        darkToggleBtn.addEventListener('click', () => {
            const currentTheme = document.documentElement.getAttribute('data-bs-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-bs-theme', newTheme);
            localStorage.setItem('bv_theme', newTheme);

            // If user is authenticated, sync with server profile
            fetch('/auth/toggle-dark-mode/', {
                method: 'POST',
                headers: {
                    'X-CSRFToken': csrftoken,
                    'Content-Type': 'application/json'
                }
            }).catch(() => {});
        });
    }

    // Restore saved theme
    const savedTheme = localStorage.getItem('bv_theme');
    if (savedTheme) {
        document.documentElement.setAttribute('data-bs-theme', savedTheme);
    }

    const savedPreset = localStorage.getItem('bv_luxury_theme');
    if (savedPreset) {
        document.documentElement.setAttribute('data-theme-preset', savedPreset);
    }
});

// Interactive Favorite Toggle
function toggleFavorite(bookId, buttonEl) {
    fetch(`/book/${bookId}/toggle-favorite/`, {
        method: 'POST',
        headers: {
            'X-CSRFToken': csrftoken,
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            const icon = buttonEl.querySelector('i');
            if (data.is_favorite) {
                icon.className = 'bi bi-heart-fill text-danger';
            } else {
                icon.className = 'bi bi-heart';
            }
            showToast(data.message, 'success');
        }
    })
    .catch(err => {
        showToast('Please login to save favorites.', 'warning');
    });
}

// Interactive Recommendation Feedback
function submitRecFeedback(bookId, action, btnEl) {
    const formData = new FormData();
    formData.append('action', action);

    fetch(`/recommendations/feedback/${bookId}/`, {
        method: 'POST',
        headers: {
            'X-CSRFToken': csrftoken
        },
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            showToast(data.message, 'success');
            if (action === 'dislike' || action === 'not_interested') {
                const card = btnEl.closest('.col-rec-item');
                if (card) {
                    card.style.opacity = '0.3';
                    card.style.pointerEvents = 'none';
                }
            }
        }
    })
    .catch(err => {
        showToast('Error recording feedback', 'danger');
    });
}
