import json
from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.db.models import Count
from django.utils import timezone
from datetime import timedelta

from books.models import Book, Favorite, ReadingProgress, ReadingGoal, Genre
from recommendations.models import Recommendation
from notifications.models import Notification
from analytics.models import UserActivityLog

@login_required
def user_dashboard(request):
    """
    Personalized SaaS Reader Dashboard with live metrics, streak tracking,
    reading challenges, reading charts and quick actions.
    """
    user = request.user
    profile = getattr(user, 'profile', None)

    # 1. Summary metrics
    books_read_count = ReadingProgress.objects.filter(user=user, status='completed').count()
    currently_reading_count = ReadingProgress.objects.filter(user=user, status='currently_reading').count()
    favorites_count = Favorite.objects.filter(user=user).count()
    reading_streak = profile.reading_streak_days if profile else 0

    # 2. Reading Goal Progress
    current_year = timezone.now().year
    goal, _ = ReadingGoal.objects.get_or_create(
        user=user,
        year=current_year,
        defaults={'target_books': profile.reading_goal_annual if profile else 12}
    )

    # 3. Continue Reading items
    continue_reading = ReadingProgress.objects.filter(
        user=user,
        status='currently_reading'
    ).select_related('book').order_by('-updated_at')[:4]

    # 4. Top AI Recommendations
    ai_recommendations = Recommendation.objects.filter(
        user=user,
        is_dismissed=False
    ).select_related('book').order_by('-score')[:4]

    # 5. Saved / Favorite Books
    saved_books = Favorite.objects.filter(user=user).select_related('book').order_by('-created_at')[:6]

    # 6. Reading Activity Chart Data (last 7 days reading logs / progress updates)
    today = timezone.now().date()
    dates = [(today - timedelta(days=i)) for i in range(6, -1, -1)]
    chart_labels = [d.strftime('%a') for d in dates]
    
    activity_counts = []
    for d in dates:
        count = ReadingProgress.objects.filter(
            user=user,
            updated_at__date=d
        ).count()
        activity_counts.append(count)

    # 7. Favorite Genres Distribution
    genre_data_qs = Genre.objects.filter(
        books__reader_progress__user=user
    ).annotate(count=Count('books')).order_by('-count')[:5]

    genre_labels = [g.name for g in genre_data_qs]
    genre_counts = [g.count for g in genre_data_qs]

    if not genre_labels:
        if profile and profile.preferred_genres.exists():
            genre_labels = [g.name for g in profile.preferred_genres.all()[:5]]
            genre_counts = [1] * len(genre_labels)
        else:
            top_genres = Genre.objects.annotate(c=Count('books')).order_by('-c')[:5]
            genre_labels = [g.name for g in top_genres]
            genre_counts = [g.c for g in top_genres]

    context = {
        'profile': profile,
        'books_read_count': books_read_count,
        'currently_reading_count': currently_reading_count,
        'favorites_count': favorites_count,
        'reading_streak': reading_streak,
        'goal': goal,
        'continue_reading': continue_reading,
        'ai_recommendations': ai_recommendations,
        'saved_books': saved_books,
        'chart_labels_json': json.dumps(chart_labels),
        'chart_data_json': json.dumps(activity_counts),
        'genre_labels_json': json.dumps(genre_labels),
        'genre_data_json': json.dumps(genre_counts),
    }
    return render(request, 'dashboard/user_dashboard.html', context)


@login_required
def live_dashboard_stats(request):
    """
    Real-time JSON endpoint for live telemetry updates.
    """
    user = request.user
    profile = getattr(user, 'profile', None)

    books_read_count = ReadingProgress.objects.filter(user=user, status='completed').count()
    currently_reading_count = ReadingProgress.objects.filter(user=user, status='currently_reading').count()
    favorites_count = Favorite.objects.filter(user=user).count()
    reading_streak = profile.reading_streak_days if profile else 0

    today = timezone.now().date()
    dates = [(today - timedelta(days=i)) for i in range(6, -1, -1)]
    chart_labels = [d.strftime('%a') for d in dates]
    activity_counts = [
        ReadingProgress.objects.filter(user=user, updated_at__date=d).count()
        for d in dates
    ]

    return JsonResponse({
        'status': 'success',
        'books_read_count': books_read_count,
        'currently_reading_count': currently_reading_count,
        'favorites_count': favorites_count,
        'reading_streak': reading_streak,
        'chart_labels': chart_labels,
        'chart_data': activity_counts,
    })
