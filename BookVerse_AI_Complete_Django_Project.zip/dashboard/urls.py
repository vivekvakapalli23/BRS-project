from django.urls import path
from . import views

app_name = 'dashboard'

urlpatterns = [
    path('', views.user_dashboard, name='user_dashboard'),
    path('api/live-stats/', views.live_dashboard_stats, name='live_stats'),
]
