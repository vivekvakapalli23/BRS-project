from django import forms
from books.models import Book, Author, Genre, Publisher, Subject

class BookAdminForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = [
            'title', 'subtitle', 'authors', 'genres', 'subjects', 'publisher',
            'publication_year', 'isbn', 'isbn13', 'language', 'page_count',
            'description', 'cover_image', 'cover_url', 'is_featured', 'is_trending',
            'pdf_file', 'epub_file', 'text_content', 'sample_extract'
        ]
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'subtitle': forms.TextInput(attrs={'class': 'form-control'}),
            'authors': forms.SelectMultiple(attrs={'class': 'form-select', 'size': '5'}),
            'genres': forms.SelectMultiple(attrs={'class': 'form-select', 'size': '5'}),
            'subjects': forms.SelectMultiple(attrs={'class': 'form-select', 'size': '5'}),
            'publisher': forms.Select(attrs={'class': 'form-select'}),
            'publication_year': forms.NumberInput(attrs={'class': 'form-control'}),
            'isbn': forms.TextInput(attrs={'class': 'form-control'}),
            'isbn13': forms.TextInput(attrs={'class': 'form-control'}),
            'language': forms.TextInput(attrs={'class': 'form-control'}),
            'page_count': forms.NumberInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 4}),
            'cover_url': forms.URLInput(attrs={'class': 'form-control', 'placeholder': 'https://...'}),
            'is_featured': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'is_trending': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'text_content': forms.Textarea(attrs={'class': 'form-control', 'rows': 6}),
            'sample_extract': forms.Textarea(attrs={'class': 'form-control', 'rows': 4}),
        }


class AuthorAdminForm(forms.ModelForm):
    class Meta:
        model = Author
        fields = ['name', 'bio', 'birth_year', 'photo', 'photo_url']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'bio': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'birth_year': forms.NumberInput(attrs={'class': 'form-control'}),
            'photo_url': forms.URLInput(attrs={'class': 'form-control'}),
        }


class GenreAdminForm(forms.ModelForm):
    class Meta:
        model = Genre
        fields = ['name', 'description', 'icon']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'icon': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'bi-book'}),
        }


class OpenLibraryImportForm(forms.Form):
    query = forms.CharField(
        max_length=200,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Search Open Library (e.g. Science Fiction, Orwell...)'})
    )
    limit = forms.IntegerField(
        initial=5,
        min_value=1,
        max_value=20,
        widget=forms.NumberInput(attrs={'class': 'form-control'})
    )


class CSVImportForm(forms.Form):
    csv_file = forms.FileField(
        required=True,
        help_text="Upload a CSV with columns: title, author, genre, year, isbn, description",
        widget=forms.FileInput(attrs={'class': 'form-control'})
    )
