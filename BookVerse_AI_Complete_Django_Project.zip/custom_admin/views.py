import csv
import json
import io
from datetime import timedelta
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib import messages
from django.http import HttpResponse, JsonResponse
from django.db.models import Count, Avg
from django.utils import timezone
from django.contrib.auth.models import User
from django.core.paginator import Paginator

from books.models import Book, Author, Genre, Publisher, Subject, ReadingProgress
from books.services import search_open_library
from community.models import Review, ReviewReport
from recommendations.models import Recommendation, ModelVersion
from recommendations.engine import RecommendationEngine
from ontology.models import OntologyMetadata
from ontology.generator import generate_bookverse_ontology
from .forms import BookAdminForm, AuthorAdminForm, GenreAdminForm, OpenLibraryImportForm, CSVImportForm

@staff_member_required
def admin_dashboard(request):
    """
    Central Executive Admin Dashboard with real-time analytics, status metrics, and charts.
    """
    total_books = Book.objects.count()
    total_users = User.objects.count()
    active_readers = ReadingProgress.objects.filter(status='currently_reading').values('user').distinct().count()
    total_recs = Recommendation.objects.count()

    thirty_days_ago = timezone.now() - timedelta(days=30)
    monthly_new_users = User.objects.filter(date_joined__gte=thirty_days_ago).count()
    books_read = ReadingProgress.objects.filter(status='completed').count()

    avg_rating_val = Book.objects.aggregate(avg=Avg('average_rating'))['avg'] or 0.0
    avg_book_rating = round(avg_rating_val, 2)

    active_model = ModelVersion.objects.filter(is_active=True).first()
    model_status = f"{active_model.model_name} (v{active_model.version})" if active_model else "Ready / Untrained"

    # Charts:
    # 1. Monthly Registrations (last 6 months)
    month_labels = []
    month_data = []
    for i in range(5, -1, -1):
        m_date = timezone.now() - timedelta(days=i * 30)
        month_labels.append(m_date.strftime('%b %Y'))
        c = User.objects.filter(date_joined__year=m_date.year, date_joined__month=m_date.month).count()
        month_data.append(c)

    # 2. Popular Genres
    top_genres = Genre.objects.annotate(b_count=Count('books')).order_by('-b_count')[:6]
    genre_labels = [g.name for g in top_genres]
    genre_data = [g.b_count for g in top_genres]

    # 3. Most Read Books
    most_read_books = Book.objects.annotate(read_count=Count('reader_progress')).order_by('-read_count')[:5]
    most_read_labels = [b.title[:20] for b in most_read_books]
    most_read_data = [b.read_count for b in most_read_books]

    # 4. Rating Distribution (1 to 5 stars)
    rating_distribution = [
        Review.objects.filter(rating=1).count(),
        Review.objects.filter(rating=2).count(),
        Review.objects.filter(rating=3).count(),
        Review.objects.filter(rating=4).count(),
        Review.objects.filter(rating=5).count(),
    ]

    ontology_meta = OntologyMetadata.objects.first()

    context = {
        'total_books': total_books,
        'total_users': total_users,
        'active_readers': active_readers,
        'total_recs': total_recs,
        'monthly_new_users': monthly_new_users,
        'books_read': books_read,
        'avg_book_rating': avg_book_rating,
        'model_status': model_status,
        'active_model': active_model,
        'ontology_meta': ontology_meta,
        'month_labels_json': json.dumps(month_labels),
        'month_data_json': json.dumps(month_data),
        'genre_labels_json': json.dumps(genre_labels),
        'genre_data_json': json.dumps(genre_data),
        'most_read_labels_json': json.dumps(most_read_labels),
        'most_read_data_json': json.dumps(most_read_data),
        'rating_dist_json': json.dumps(rating_distribution),
    }
    return render(request, 'custom_admin/dashboard.html', context)


# ---------------- BOOK MANAGEMENT ----------------

@staff_member_required
def manage_books(request):
    query = request.GET.get('q', '').strip()
    books = Book.objects.all().prefetch_related('authors', 'genres')
    if query:
        books = books.filter(title__icontains=query)
    
    paginator = Paginator(books, 15)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'custom_admin/manage_books.html', {'page_obj': page_obj, 'q': query})


@staff_member_required
def book_create(request):
    if request.method == 'POST':
        form = BookAdminForm(request.POST, request.FILES)
        if form.is_valid():
            book = form.save()
            messages.success(request, f"Book '{book.title}' created successfully!")
            return redirect('custom_admin:manage_books')
    else:
        form = BookAdminForm()
    return render(request, 'custom_admin/book_form.html', {'form': form, 'title': 'Add New Book'})


@staff_member_required
def book_edit(request, pk):
    book = get_object_or_404(Book, pk=pk)
    if request.method == 'POST':
        form = BookAdminForm(request.POST, request.FILES, instance=book)
        if form.is_valid():
            form.save()
            messages.success(request, f"Book '{book.title}' updated successfully!")
            return redirect('custom_admin:manage_books')
    else:
        form = BookAdminForm(instance=book)
    return render(request, 'custom_admin/book_form.html', {'form': form, 'book': book, 'title': f"Edit {book.title}"})


@staff_member_required
def book_delete(request, pk):
    book = get_object_or_404(Book, pk=pk)
    if request.method == 'POST':
        title = book.title
        book.delete()
        messages.success(request, f"Book '{title}' was deleted.")
        return redirect('custom_admin:manage_books')
    return render(request, 'custom_admin/confirm_delete.html', {'object': book, 'type': 'Book'})


# ---------------- AUTHOR MANAGEMENT ----------------

@staff_member_required
def manage_authors(request):
    authors = Author.objects.annotate(b_count=Count('books')).order_by('name')
    paginator = Paginator(authors, 15)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'custom_admin/manage_authors.html', {'page_obj': page_obj})


@staff_member_required
def author_create(request):
    if request.method == 'POST':
        form = AuthorAdminForm(request.POST, request.FILES)
        if form.is_valid():
            author = form.save()
            messages.success(request, f"Author '{author.name}' added successfully!")
            return redirect('custom_admin:manage_authors')
    else:
        form = AuthorAdminForm()
    return render(request, 'custom_admin/author_form.html', {'form': form, 'title': 'Add Author'})


# ---------------- GENRE MANAGEMENT ----------------

@staff_member_required
def manage_genres(request):
    genres = Genre.objects.annotate(b_count=Count('books')).order_by('name')
    return render(request, 'custom_admin/manage_genres.html', {'genres': genres})


@staff_member_required
def genre_create(request):
    if request.method == 'POST':
        form = GenreAdminForm(request.POST)
        if form.is_valid():
            genre = form.save()
            messages.success(request, f"Genre '{genre.name}' created!")
            return redirect('custom_admin:manage_genres')
    else:
        form = GenreAdminForm()
    return render(request, 'custom_admin/genre_form.html', {'form': form})


# ---------------- USER MANAGEMENT ----------------

@staff_member_required
def manage_users(request):
    users = User.objects.all().select_related('profile').order_by('-date_joined')
    paginator = Paginator(users, 20)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'custom_admin/manage_users.html', {'page_obj': page_obj})


@staff_member_required
def toggle_user_status(request, user_id):
    u = get_object_or_404(User, id=user_id)
    if u != request.user:
        u.is_active = not u.is_active
        u.save()
        messages.success(request, f"User {u.username} status toggled to {'Active' if u.is_active else 'Disabled'}.")
    return redirect('custom_admin:manage_users')


# ---------------- REVIEW MODERATION ----------------

@staff_member_required
def manage_reviews(request):
    reviews = Review.objects.all().select_related('user', 'book').order_by('-created_at')
    reports = ReviewReport.objects.filter(is_resolved=False).select_related('user', 'review', 'review__book')
    return render(request, 'custom_admin/manage_reviews.html', {'reviews': reviews, 'reports': reports})


@staff_member_required
def toggle_review_approval(request, review_id):
    r = get_object_or_404(Review, id=review_id)
    r.is_approved = not r.is_approved
    r.save()
    messages.success(request, f"Review status updated to {'Approved' if r.is_approved else 'Unapproved'}.")
    return redirect('custom_admin:manage_reviews')


# ---------------- OPEN LIBRARY IMPORT ----------------

@staff_member_required
def open_library_import_view(request):
    results = []
    query = ""
    form = OpenLibraryImportForm(request.GET or None)
    if form.is_valid():
        query = form.cleaned_data['query']
        limit = form.cleaned_data['limit']
        results = search_open_library(query, limit=limit)

    return render(request, 'custom_admin/open_library_import.html', {
        'form': form,
        'results': results,
        'query': query
    })


@staff_member_required
def save_open_library_book(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        author_name = request.POST.get('author_name', 'Unknown')
        pub_year = request.POST.get('year')
        cover_url = request.POST.get('cover_url', '')
        isbn = request.POST.get('isbn', '')

        # Create or fetch Author
        author, _ = Author.objects.get_or_create(name=author_name)

        # Default genre
        genre, _ = Genre.objects.get_or_create(name="Literature")

        book, created = Book.objects.get_or_create(
            title=title,
            defaults={
                'publication_year': int(pub_year) if pub_year and pub_year.isdigit() else None,
                'cover_url': cover_url,
                'isbn': isbn,
                'description': f"Acclaimed work by {author_name}. Imported via Open Library.",
            }
        )
        book.authors.add(author)
        book.genres.add(genre)
        messages.success(request, f"Successfully imported '{title}' into BookVerse catalog!")

    return redirect('custom_admin:open_library_import')


# ---------------- CSV IMPORT ----------------

@staff_member_required
def csv_import_view(request):
    if request.method == 'POST':
        form = CSVImportForm(request.POST, request.FILES)
        if form.is_valid():
            csv_file = request.FILES['csv_file']
            decoded_file = csv_file.read().decode('utf-8')
            io_string = io.StringIO(decoded_file)
            reader = csv.DictReader(io_string)
            imported_count = 0
            for row in reader:
                title = row.get('title')
                if not title:
                    continue
                author_name = row.get('author', 'Unknown Author')
                genre_name = row.get('genre', 'General')
                year = row.get('year')
                isbn = row.get('isbn', '')
                desc = row.get('description', '')

                author, _ = Author.objects.get_or_create(name=author_name.strip())
                genre, _ = Genre.objects.get_or_create(name=genre_name.strip())

                book, created = Book.objects.get_or_create(
                    title=title.strip(),
                    defaults={
                        'publication_year': int(year) if year and year.isdigit() else None,
                        'isbn': isbn.strip(),
                        'description': desc.strip(),
                    }
                )
                book.authors.add(author)
                book.genres.add(genre)
                imported_count += 1

            messages.success(request, f"Bulk CSV Import complete! {imported_count} books processed.")
            return redirect('custom_admin:manage_books')
    else:
        form = CSVImportForm()
    return render(request, 'custom_admin/csv_import.html', {'form': form})


# ---------------- ML TRAINING & ONTOLOGY CONTROLS ----------------

@staff_member_required
def train_models_view(request):
    engine = RecommendationEngine()
    result = engine.train_models()
    if result.get('status') == 'success':
        messages.success(request, f"Recommendation model training succeeded! Version: {result.get('version')}")
    else:
        messages.warning(request, result.get('message', 'Training completed with warnings.'))
    return redirect('custom_admin:admin_dashboard')


@staff_member_required
def rebuild_ontology_view(request):
    res = generate_bookverse_ontology()
    messages.success(request, f"Knowledge graph ontology rebuilt! {res['triples_count']} semantic triples created.")
    return redirect('custom_admin:admin_dashboard')


@staff_member_required
def export_books_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="bookverse_books_catalog.csv"'
    writer = csv.writer(response)
    writer.writerow(['ID', 'Title', 'Authors', 'Genres', 'Rating', 'Ratings Count', 'Year', 'ISBN'])
    for b in Book.objects.all().prefetch_related('authors', 'genres'):
        authors = ", ".join([a.name for a in b.authors.all()])
        genres = ", ".join([g.name for g in b.genres.all()])
        writer.writerow([b.id, b.title, authors, genres, b.average_rating, b.ratings_count, b.publication_year, b.isbn])
    return response
