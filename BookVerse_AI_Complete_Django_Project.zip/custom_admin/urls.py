from django.urls import path
from . import views

app_name = 'custom_admin'

urlpatterns = [
    path('', views.admin_dashboard, name='admin_dashboard'),
    path('books/', views.manage_books, name='manage_books'),
    path('books/create/', views.book_create, name='book_create'),
    path('books/<int:pk>/edit/', views.book_edit, name='book_edit'),
    path('books/<int:pk>/delete/', views.book_delete, name='book_delete'),
    path('authors/', views.manage_authors, name='manage_authors'),
    path('authors/create/', views.author_create, name='author_create'),
    path('genres/', views.manage_genres, name='manage_genres'),
    path('genres/create/', views.genre_create, name='genre_create'),
    path('users/', views.manage_users, name='manage_users'),
    path('users/<int:user_id>/toggle/', views.toggle_user_status, name='toggle_user_status'),
    path('reviews/', views.manage_reviews, name='manage_reviews'),
    path('reviews/<int:review_id>/toggle/', views.toggle_review_approval, name='toggle_review_approval'),
    path('import/open-library/', views.open_library_import_view, name='open_library_import'),
    path('import/open-library/save/', views.save_open_library_book, name='save_open_library_book'),
    path('import/csv/', views.csv_import_view, name='csv_import'),
    path('ml/train/', views.train_models_view, name='train_models'),
    path('ontology/rebuild/', views.rebuild_ontology_view, name='rebuild_ontology'),
    path('export/books/', views.export_books_csv, name='export_books_csv'),
]
