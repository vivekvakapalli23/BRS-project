from django.urls import path
from . import views

app_name = 'assistant'

urlpatterns = [
    path('', views.assistant_chat_view, name='chat'),
    path('api/send/', views.send_chat_message, name='send_message'),
]
