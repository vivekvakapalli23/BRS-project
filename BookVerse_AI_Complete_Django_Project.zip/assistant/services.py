import re
from django.db.models import Q
from books.models import Book, Author, Genre
from .models import ChatMessage

# Comprehensive book, literature, reading & publishing keyword set
BOOK_KEYWORDS = {
    'book', 'books', 'novel', 'novels', 'author', 'authors', 'writer', 'writers',
    'read', 'reading', 'reader', 'readers', 'literature', 'literary', 'story', 'stories',
    'chapter', 'chapters', 'page', 'pages', 'genre', 'genres', 'recommend', 'recommendation',
    'recommendations', 'plan', 'routine', 'schedule', 'publisher', 'publishers',
    'isbn', 'summary', 'synopsis', 'library', 'shelf', 'shelves', 'poem', 'poetry',
    'fiction', 'non-fiction', 'dystopian', 'dystopia', 'sci-fi', 'scifi', 'science fiction',
    'philosophy', 'philosophical', 'psychology', 'psychological', 'mystery', 'thriller',
    'fantasy', 'biography', 'autobiography', 'memoir', 'character', 'characters',
    'plot', 'prose', 'verse', 'ebook', 'ebooks', 'epub', 'pdf', 'kindle', 'bestseller',
    'classic', 'classics', 'hardcover', 'paperback', 'tale', 'tales', 'volume', 'volumes'
}

class BookVerseAssistant:
    """
    Dedicated AI Book & Literature Assistant.
    Strictly answers queries regarding books, literature, authors, reading plans,
    and reading recommendations. Flags and rejects unrelated questions with an
    explicit 'books-only' notice and popup message.
    """

    def is_query_book_related(self, query):
        clean_q = query.lower().strip()
        tokens = set(re.findall(r'\b[a-z]{3,}\b', clean_q))

        # 1. Direct book keyword intersection
        if tokens.intersection(BOOK_KEYWORDS):
            return True

        # 2. Check for multi-word phrases (e.g., 'reading plan', 'sci-fi')
        for phrase in ['reading plan', 'sci fi', 'sci-fi', 'science fiction', 'read online', 'book list']:
            if phrase in clean_q:
                return True

        # 3. Check against database Authors
        for author_name in Author.objects.values_list('name', flat=True):
            if author_name.lower() in clean_q:
                return True

        # 4. Check against database Book Titles
        for title in Book.objects.values_list('title', flat=True):
            if title.lower() in clean_q:
                return True

        # 5. Check against database Genres
        for genre_name in Genre.objects.values_list('name', flat=True):
            if genre_name.lower() in clean_q:
                return True

        # 6. Basic friendly greetings
        if clean_q in ['hi', 'hello', 'hey', 'greetings', 'good morning', 'good afternoon', 'good evening', 'help']:
            return True

        return False

    def process_message(self, user, session_id, message_text):
        query = message_text.lower().strip()
        matched_books = []
        is_book_related = self.is_query_book_related(query)

        # Non-book related queries trigger popup & restriction
        if not is_book_related:
            response_text = (
                "⚠️ **I will give books related information only!**\n\n"
                "I am exclusively trained on the **BookVerse AI Literature Knowledge Base**. "
                "I cannot assist with general topics, politics, coding, or unrelated queries.\n\n"
                "👉 *Please ask me anything regarding:*\n"
                "- Book recommendations by genre, mood, or theme\n"
                "- Questions about authors, novels, or synopses\n"
                "- Creating a personalized 4-week reading schedule\n"
                "- Books similar to your favorite classics"
            )
            # Record message
            ChatMessage.objects.create(
                user=user if user and user.is_authenticated else None,
                session_id=session_id,
                role='assistant',
                content=response_text
            )
            return {
                'role': 'assistant',
                'is_book_related': False,
                'popup_message': 'I will give books related information only! Please ask questions about books, authors, genres, or reading plans.',
                'content': response_text,
                'books': []
            }

        # Handling Greetings
        if query in ['hi', 'hello', 'hey', 'greetings', 'good morning', 'good afternoon', 'good evening', 'help']:
            response_text = (
                "Hello! Welcome to the **BookVerse AI Assistant** 📚\n\n"
                "I am your dedicated reading companion. I provide book and literature information only! "
                "You can ask me to:\n"
                "1. Recommend books (e.g., *'Recommend a fast-paced sci-fi'*)\n"
                "2. Create a reading plan (e.g., *'Create a 4-week reading plan'*)\n"
                "3. Inquire about authors or books (e.g., *'Tell me about George Orwell'* or *'Books like Dune'*)"
            )
            ChatMessage.objects.create(
                user=user if user and user.is_authenticated else None,
                session_id=session_id,
                role='assistant',
                content=response_text
            )
            return {
                'role': 'assistant',
                'is_book_related': True,
                'popup_message': '',
                'content': response_text,
                'books': []
            }

        # 1. Detect Intent: Reading Plan
        if "plan" in query or "schedule" in query or "routine" in query:
            genre_match = self._find_genre(query)
            if genre_match:
                plan_books = list(Book.objects.filter(genres=genre_match).order_by('-average_rating')[:4])
            else:
                plan_books = list(Book.objects.order_by('-average_rating')[:4])

            matched_books = plan_books
            response_text = (
                "### 📚 Personalized 4-Week Reading Plan\n\n"
                "Here is a structured, balanced reading schedule crafted for you:\n\n"
            )
            for i, b in enumerate(plan_books, start=1):
                response_text += f"- **Week {i}**: [{b.title}]({b.get_absolute_url()}) by {b.authors_display} ({b.page_count} pages ~ {max(10, b.page_count // 7)} pages/day)\n"
            response_text += "\n*Tip: Log your daily reading in your BookVerse Dashboard to maintain your reading streak!*"

        # 2. Detect Intent: Recommend books like a specific book/author/genre
        elif "like" in query or "similar" in query or "recommend" in query:
            found_author = None
            for author in Author.objects.all():
                if author.name.lower() in query:
                    found_author = author
                    break

            if found_author:
                author_books = list(found_author.books.all()[:4])
                genre_books = list(Book.objects.filter(
                    genres__in=Genre.objects.filter(books__authors=found_author)
                ).exclude(authors=found_author).distinct()[:3])
                matched_books = author_books + genre_books
                response_text = (
                    f"If you enjoy the literary style of **{found_author.name}**, you'll appreciate these titles:\n\n"
                )
                for b in matched_books:
                    response_text += f"- **[{b.title}]({b.get_absolute_url()})** ({b.average_rating}★) - {b.genres_display}\n  _{b.description[:120]}..._\n\n"
            else:
                matched_books = self._search_books(query)
                if matched_books:
                    response_text = "Based on your reading taste, here are top-tier recommendations from our AI knowledge base:\n\n"
                    for b in matched_books:
                        response_text += f"- **[{b.title}]({b.get_absolute_url()})** by {b.authors_display} ({b.average_rating}★)\n  *Why:* Matches your thematic interest in {b.genres_display}.\n\n"
                else:
                    matched_books = list(Book.objects.order_by('-average_rating')[:3])
                    response_text = "Here are our community's highest-rated literary masterpieces you might enjoy:\n\n"
                    for b in matched_books:
                        response_text += f"- **[{b.title}]({b.get_absolute_url()})** by {b.authors_display} ({b.average_rating}★)\n"

        # 3. Detect Intent: Author or Book Information
        elif "who is" in query or "tell me about" in query or "summary" in query or "about" in query:
            book_match = None
            for b in Book.objects.all():
                if b.title.lower() in query:
                    book_match = b
                    break
            
            if book_match:
                matched_books = [book_match]
                response_text = (
                    f"### 📖 About *{book_match.title}*\n\n"
                    f"- **Author:** {book_match.authors_display}\n"
                    f"- **Published:** {book_match.publication_year or 'N/A'}\n"
                    f"- **Rating:** {book_match.average_rating}★ ({book_match.ratings_count} reviews)\n"
                    f"- **Genre:** {book_match.genres_display}\n\n"
                    f"**Synopsis:** {book_match.description or 'A captivating read in our catalog.'}\n\n"
                    f"[Click here to explore or read online]({book_match.get_absolute_url()})"
                )
            else:
                matched_books = self._search_books(query)
                if matched_books:
                    response_text = "Here is what I found regarding your literature search:\n\n"
                    for b in matched_books:
                        response_text += f"- **[{b.title}]({b.get_absolute_url()})** by {b.authors_display}\n"
                else:
                    response_text = (
                        "I am your **BookVerse AI Literature Assistant**. I provide book information only! "
                        "Try asking: *'Recommend a sci-fi book'*, *'Create a reading plan'*, or *'Books like 1984'*!"
                    )

        else:
            matched_books = self._search_books(query)
            if matched_books:
                response_text = "Here are books matching your literary interests:\n\n"
                for b in matched_books:
                    response_text += f"- **[{b.title}]({b.get_absolute_url()})** by {b.authors_display} ({b.average_rating}★)\n"
            else:
                response_text = (
                    "I am your **BookVerse AI Literature Assistant** (books information only). "
                    "Try asking about a book title, an author, a genre, or requesting a reading plan!"
                )

        # Save assistant response
        msg_obj = ChatMessage.objects.create(
            user=user if user and user.is_authenticated else None,
            session_id=session_id,
            role='assistant',
            content=response_text
        )
        if matched_books:
            msg_obj.suggested_books.set(matched_books)

        return {
            'role': 'assistant',
            'is_book_related': True,
            'popup_message': '',
            'content': response_text,
            'books': [{
                'id': b.id,
                'title': b.title,
                'author': b.authors_display,
                'rating': float(b.average_rating),
                'cover_url': b.get_cover_url,
                'url': b.get_absolute_url()
            } for b in matched_books]
        }

    def _find_genre(self, query):
        for g in Genre.objects.all():
            if g.name.lower() in query:
                return g
        return None

    def _search_books(self, query):
        words = re.findall(r'\b\w{3,}\b', query)
        if not words:
            return []
        
        q_obj = Q()
        for w in words[:4]:
            q_obj |= Q(title__icontains=w) | Q(description__icontains=w) | Q(genres__name__icontains=w) | Q(authors__name__icontains=w)

        return list(Book.objects.filter(q_obj).distinct()[:5])
