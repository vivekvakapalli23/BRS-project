import uuid
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.http import require_POST

from .models import ChatMessage
from .services import BookVerseAssistant

def assistant_chat_view(request):
    """
    Renders conversational assistant interface with chat session history.
    """
    session_id = request.session.get('chat_session_id')
    if not session_id:
        session_id = str(uuid.uuid4())
        request.session['chat_session_id'] = session_id

    messages_qs = ChatMessage.objects.filter(session_id=session_id).prefetch_related('suggested_books')
    return render(request, 'assistant/chat.html', {
        'messages': messages_qs,
        'session_id': session_id
    })


@require_POST
def send_chat_message(request):
    """
    API endpoint for posting messages to the AI assistant.
    """
    session_id = request.session.get('chat_session_id') or str(uuid.uuid4())
    request.session['chat_session_id'] = session_id

    user_text = request.POST.get('message', '').strip()
    if not user_text:
        return JsonResponse({'status': 'error', 'message': 'Message cannot be empty.'}, status=400)

    user = request.user if request.user.is_authenticated else None

    # Persist user message
    ChatMessage.objects.create(
        user=user,
        session_id=session_id,
        role='user',
        content=user_text
    )

    # Process via Local AI Engine
    assistant = BookVerseAssistant()
    response_data = assistant.process_message(user, session_id, user_text)

    return JsonResponse({
        'status': 'success',
        'response': response_data
    })
