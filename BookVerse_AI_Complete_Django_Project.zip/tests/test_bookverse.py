from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse

from books.models import Book, Author, Genre, Publisher, Favorite, ReadingProgress
from community.models import Review
from recommendations.models import Recommendation, ModelVersion
from recommendations.engine import RecommendationEngine
from ontology.generator import generate_bookverse_ontology
from books.services import search_open_library

class BookVerseComprehensiveTestSuite(TestCase):
    def setUp(self):
        self.client = Client()
        # Admin User
        self.admin_user = User.objects.create_superuser('testadmin', 'admin@test.com', 'adminpass123')
        # Regular User
        self.reader_user = User.objects.create_user('testreader', 'reader@test.com', 'readerpass123')

        # Sample Genre, Author, Publisher
        self.genre = Genre.objects.create(name='Sci-Fi', slug='sci-fi')
        self.author = Author.objects.create(name='Arthur C. Clarke', slug='arthur-clarke')
        self.publisher = Publisher.objects.create(name='Orbit Books')

        # Sample Book
        self.book = Book.objects.create(
            title='2001: A Space Odyssey',
            slug='2001-a-space-odyssey',
            publication_year=1968,
            isbn='9780451457998',
            page_count=297,
            average_rating=4.8,
            ratings_count=10,
            publisher=self.publisher
        )
        self.book.genres.add(self.genre)
        self.book.authors.add(self.author)

    def test_authentication_workflow(self):
        # Login regular user
        login_success = self.client.login(username='testreader', password='readerpass123')
        self.assertTrue(login_success)
        response = self.client.get(reverse('dashboard:user_dashboard'))
        self.assertEqual(response.status_code, 200)

        # Logout
        self.client.logout()
        response = self.client.get(reverse('dashboard:user_dashboard'))
        self.assertEqual(response.status_code, 302) # Redirects to login

    def test_auth_pages_render(self):
        # Test login page renders with HTTP 200 without NoReverseMatch
        resp_login = self.client.get(reverse('accounts:login'))
        self.assertEqual(resp_login.status_code, 200)

        # Test register page renders with HTTP 200
        resp_register = self.client.get(reverse('accounts:register'))
        self.assertEqual(resp_register.status_code, 200)

        # Test password reset page renders with HTTP 200
        resp_reset = self.client.get(reverse('accounts:password_reset'))
        self.assertEqual(resp_reset.status_code, 200)


    def test_admin_authorization(self):
        # Non-staff cannot access custom admin
        self.client.login(username='testreader', password='readerpass123')
        response = self.client.get(reverse('custom_admin:admin_dashboard'))
        self.assertEqual(response.status_code, 302)

        # Staff can access custom admin
        self.client.login(username='testadmin', password='adminpass123')
        response = self.client.get(reverse('custom_admin:admin_dashboard'))
        self.assertEqual(response.status_code, 200)

    def test_book_search_and_filters(self):
        response = self.client.get(reverse('books:explore'), {'q': 'Space Odyssey'})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, '2001: A Space Odyssey')

        # Filter by genre
        response = self.client.get(reverse('books:explore'), {'genre': 'sci-fi'})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, '2001: A Space Odyssey')

    def test_reading_progress_and_streak(self):
        self.client.login(username='testreader', password='readerpass123')
        response = self.client.post(reverse('reader:save_progress', kwargs={'book_id': self.book.id}), {
            'current_page': 50,
            'total_pages': 297,
            'location': 'Chapter 5'
        })
        self.assertEqual(response.status_code, 200)
        progress = ReadingProgress.objects.get(user=self.reader_user, book=self.book)
        self.assertEqual(progress.current_page, 50)
        self.assertEqual(progress.status, 'currently_reading')

    def test_review_submission_and_rating_metric_update(self):
        self.client.login(username='testreader', password='readerpass123')
        response = self.client.post(reverse('community:submit_review', kwargs={'book_id': self.book.id}), {
            'rating': 5,
            'title': 'Stunning Masterpiece',
            'content': 'An extraordinary vision of cosmic human evolution.'
        })
        self.assertEqual(response.status_code, 302)
        review = Review.objects.get(user=self.reader_user, book=self.book)
        self.assertEqual(review.rating, 5)

        # Confirm book average rating refreshed
        self.book.refresh_from_db()
        self.assertEqual(float(self.book.average_rating), 5.0)

    def test_ontology_generation(self):
        meta = generate_bookverse_ontology()
        self.assertGreater(meta['triples_count'], 0)
        self.assertEqual(meta['classes_count'], 11)
        self.assertEqual(meta['properties_count'], 10)

    def test_recommendation_engine(self):
        engine = RecommendationEngine()
        train_res = engine.train_models()
        self.assertEqual(train_res['status'], 'success')

        # Generate recommendations
        recs = engine.generate_recommendations_for_user(self.reader_user, top_k=5)
        self.assertIsNotNone(recs)

    def test_external_api_fallback(self):
        # Testing search with non-existent query or simulation
        res = search_open_library("query_with_no_direct_match_xyz123456789")
        self.assertIsInstance(res, list)

    def test_assistant_books_only_guardrail(self):
        from assistant.services import BookVerseAssistant
        assistant = BookVerseAssistant()

        # Non-book query should be rejected with explicit message
        res_non_book = assistant.process_message(self.reader_user, 'test-sess', 'Tell me about the stock market')
        self.assertFalse(res_non_book['is_book_related'])
        self.assertIn("books related information only", res_non_book['popup_message'].lower())

        # Book query should be accepted
        res_book = assistant.process_message(self.reader_user, 'test-sess', 'Recommend a good novel')
        self.assertTrue(res_book['is_book_related'])
