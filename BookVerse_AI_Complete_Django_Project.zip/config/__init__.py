# BookVerse AI Config
try:
    import pymysql
    pymysql.version_info = (2, 2, 7, "final", 0)
    pymysql.install_as_MySQLdb()
except ImportError:
    pass

# Compatibility patch: Allow MySQL 8.0+ on Django 6.x (which defaults to 8.4+)
try:
    from django.db.backends.mysql.features import DatabaseFeatures
    from django.utils.functional import cached_property
    import django.db.backends.mysql.base as mysql_base
    from django.db.utils import NotSupportedError

    DatabaseFeatures.minimum_database_version = cached_property(
        lambda self: (10, 5) if getattr(self.connection, 'mysql_is_mariadb', False) else (8, 0)
    )

    def _allow_mysql_8_0(self):
        if getattr(self, 'mysql_is_mariadb', False):
            if self.mysql_version < (10, 5):
                raise NotSupportedError(f"MariaDB 10.5+ required (found {self.mysql_server_info}).")
        else:
            if self.mysql_version < (8, 0):
                raise NotSupportedError(f"MySQL 8.0+ required (found {self.mysql_server_info}).")

    mysql_base.DatabaseWrapper.check_database_version_supported = _allow_mysql_8_0
except Exception:
    pass
