"""BookVerse AI URL Configuration"""

from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('django-admin/', admin.site.urls),
    path('', include('books.urls', namespace='books')),
    path('auth/', include('accounts.urls', namespace='accounts')),
    path('dashboard/', include('dashboard.urls', namespace='dashboard')),
    path('admin-panel/', include('custom_admin.urls', namespace='custom_admin')),
    path('recommendations/', include('recommendations.urls', namespace='recommendations')),
    path('ontology/', include('ontology.urls', namespace='ontology')),
    path('reader/', include('reader.urls', namespace='reader')),
    path('assistant/', include('assistant.urls', namespace='assistant')),
    path('analytics/', include('analytics.urls', namespace='analytics')),
    path('community/', include('community.urls', namespace='community')),
    path('notifications/', include('notifications.urls', namespace='notifications')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATICFILES_DIRS[0])
