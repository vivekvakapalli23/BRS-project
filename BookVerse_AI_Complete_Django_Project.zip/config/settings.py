"""
Django settings for BookVerse AI project.
Ontology-Based Intelligent Book Recommendation System
"""

import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent

# Load environment variables
load_dotenv(BASE_DIR / '.env')
if not os.environ.get('DB_NAME'):
    load_dotenv(BASE_DIR.parent / '.env')


SECRET_KEY = os.environ.get(
    'SECRET_KEY',
    'django-insecure-bookverse-ai-dev-key-change-in-production-2026-secure-hash'
)

DEBUG = os.environ.get('DEBUG', 'True').lower() in ('true', '1', 'yes')

ALLOWED_HOSTS = os.environ.get('ALLOWED_HOSTS', 'localhost,127.0.0.1,testserver').split(',')

# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.humanize',

    # Third party
    'rest_framework',

    # BookVerse Apps
    'accounts.apps.AccountsConfig',
    'books.apps.BooksConfig',
    'recommendations.apps.RecommendationsConfig',
    'ontology.apps.OntologyConfig',
    'dashboard.apps.DashboardConfig',
    'custom_admin.apps.CustomAdminConfig',
    'reader.apps.ReaderConfig',
    'assistant.apps.AssistantConfig',
    'analytics.apps.AnalyticsConfig',
    'community.apps.CommunityConfig',
    'notifications.apps.NotificationsConfig',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'config.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'notifications.context_processors.unread_notifications_count',
            ],
        },
    },
]

WSGI_APPLICATION = 'config.wsgi.application'
ASGI_APPLICATION = 'config.asgi.application'

# Database Configuration - MySQL Primary with Auto-Detection & Resilient Fallback
DB_ENGINE = os.environ.get('DB_ENGINE', 'mysql').strip().lower()
DB_NAME = os.environ.get('DB_NAME', 'bookverse_db').strip()
DB_USER = os.environ.get('DB_USER', 'root').strip()
DB_PASSWORD = os.environ.get('DB_PASSWORD', '')
DB_HOST = os.environ.get('DB_HOST', '127.0.0.1').strip()
DB_PORT = os.environ.get('DB_PORT', '3306').strip()

import sys
IS_TESTING = 'test' in sys.argv

# Compatibility patch: Allow MySQL 8.0+ on Django 6.x
try:
    from django.db.backends.mysql.features import DatabaseFeatures
    from django.utils.functional import cached_property
    import django.db.backends.mysql.base as mysql_base
    DatabaseFeatures.minimum_database_version = cached_property(
        lambda self: (10, 5) if getattr(self.connection, 'mysql_is_mariadb', False) else (8, 0)
    )
    mysql_base.DatabaseWrapper.check_database_version_supported = lambda self: None
except Exception:
    pass

def setup_mysql_connection(host, user, password, port, db_name):
    """
    Tests MySQL authentication and automatically creates database if needed.
    Returns (is_ready: bool, status_message: str)
    """
    try:
        import pymysql
        conn = pymysql.connect(
            host=host,
            user=user,
            password=password,
            port=int(port),
            connect_timeout=2
        )
        with conn.cursor() as cursor:
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS `{db_name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;")
        conn.close()
        return True, "READY"
    except Exception as exc:
        err_str = str(exc)
        if "1045" in err_str:
            return False, "AUTH_FAILED"
        return False, err_str

mysql_ready = False
if DB_ENGINE == 'mysql' and not IS_TESTING:
    mysql_ready, mysql_status = setup_mysql_connection(DB_HOST, DB_USER, DB_PASSWORD, DB_PORT, DB_NAME)
    if mysql_ready:
        DATABASES = {
            'default': {
                'ENGINE': 'django.db.backends.mysql',
                'NAME': DB_NAME,
                'USER': DB_USER,
                'PASSWORD': DB_PASSWORD,
                'HOST': DB_HOST,
                'PORT': DB_PORT,
                'OPTIONS': {
                    'charset': 'utf8mb4',
                    'init_command': "SET sql_mode='STRICT_TRANS_TABLES'",
                    'connect_timeout': 5,
                },
                'TEST': {
                    'CHARSET': 'utf8mb4',
                    'COLLATION': 'utf8mb4_unicode_ci',
                }
            }
        }
    else:
        print("\n" + "="*70)
        if mysql_status == "AUTH_FAILED":
            print(" [!] MySQL AUTHENTICATION REQUIRED (127.0.0.1:3306)")
            print(f" [!] Access denied for user '{DB_USER}'. Your MySQL root requires a password.")
            print(" [!] Please open the .env file and set your MySQL password:")
            print(" [!]     DB_PASSWORD=your_mysql_password")
            print(" [!] (Temporarily using SQLite so runserver/commands work without crashing)")
        else:
            print(" [!] MySQL is not reachable on 127.0.0.1:3306.")
            print(" [!] Start MySQL in XAMPP or Windows Services to use MySQL.")
            print(" [!] (Temporarily using SQLite so runserver/commands work without crashing)")
        print("="*70 + "\n")
        DATABASES = {
            'default': {
                'ENGINE': 'django.db.backends.sqlite3',
                'NAME': BASE_DIR / 'db.sqlite3',
            }
        }
elif DB_ENGINE == 'mysql' and IS_TESTING:
    # Quiet test environment fallback
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': BASE_DIR / 'db.sqlite3',
        }
    }
else:
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': BASE_DIR / 'db.sqlite3',
        }
    }



AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
        'OPTIONS': {'min_length': 6},
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
STATIC_ROOT = BASE_DIR / 'staticfiles'

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

LOGIN_URL = 'accounts:login'
LOGIN_REDIRECT_URL = 'dashboard:user_dashboard'
LOGOUT_REDIRECT_URL = 'books:home'

# Email backend for password reset
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'


REST_FRAMEWORK = {
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticatedOrReadOnly',
    ],
    'DEFAULT_PAGINATION_CLASS': 'rest_framework.pagination.PageNumberPagination',
    'PAGE_SIZE': 12,
}

# Recommendation Engine Cache & Artifacts directory
RECOMMENDATION_ARTIFACTS_DIR = BASE_DIR / 'recommendations' / 'artifacts'
ONTOLOGY_FILES_DIR = BASE_DIR / 'ontology' / 'data'

# Ensure directories exist
os.makedirs(STATICFILES_DIRS[0], exist_ok=True)
os.makedirs(MEDIA_ROOT, exist_ok=True)
os.makedirs(RECOMMENDATION_ARTIFACTS_DIR, exist_ok=True)
os.makedirs(ONTOLOGY_FILES_DIR, exist_ok=True)
