from django.urls import path
from . import views

app_name = 'reader'

urlpatterns = [
    path('library/', views.my_library_view, name='my_library'),
    path('book/<slug:slug>/', views.online_reader, name='online_reader'),
    path('book/<int:book_id>/save-progress/', views.save_reading_progress, name='save_progress'),
    path('book/<int:book_id>/bookmark/', views.add_bookmark, name='add_bookmark'),
]
