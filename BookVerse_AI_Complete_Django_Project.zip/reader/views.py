from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.http import JsonResponse
from django.contrib import messages
from django.utils import timezone

from books.models import Book, ReadingProgress, Bookmark, Favorite, ReadingList, ReadingListItem

@login_required
def online_reader(request, slug):
    """
    Dedicated immersive ebook reader supporting PDF, EPUB, and extracted public text.
    Provides light/sepia/dark modes, font scaling, navigation, and live progress persistence.
    """
    book = get_object_or_404(Book, slug=slug)

    progress, _ = ReadingProgress.objects.get_or_create(
        user=request.user,
        book=book,
        defaults={'total_pages': book.page_count, 'status': 'currently_reading', 'started_at': timezone.now()}
    )

    if progress.status != 'completed':
        progress.status = 'currently_reading'
        if not progress.started_at:
            progress.started_at = timezone.now()
        progress.save(update_fields=['status', 'started_at', 'updated_at'])

    # Update reading streak
    if hasattr(request.user, 'profile'):
        request.user.profile.update_streak()

    user_bookmarks = Bookmark.objects.filter(user=request.user, book=book).order_by('-created_at')

    # Determine reader format
    reader_type = 'text'
    file_url = None
    if book.pdf_file:
        reader_type = 'pdf'
        file_url = book.pdf_file.url
    elif book.epub_file:
        reader_type = 'epub'
        file_url = book.epub_file.url

    context = {
        'book': book,
        'progress': progress,
        'bookmarks': user_bookmarks,
        'reader_type': reader_type,
        'file_url': file_url,
    }
    return render(request, 'reader/reader.html', context)


@login_required
@require_POST
def save_reading_progress(request, book_id):
    """
    Asynchronous endpoint to persist reading page, percentage, and CFI location.
    """
    book = get_object_or_404(Book, id=book_id)
    current_page = request.POST.get('current_page')
    total_pages = request.POST.get('total_pages')
    location = request.POST.get('location', '')

    progress, _ = ReadingProgress.objects.get_or_create(user=request.user, book=book)

    try:
        if current_page:
            progress.current_page = int(current_page)
        if total_pages:
            progress.total_pages = int(total_pages)
        if location:
            progress.last_location = str(location)
        if progress.status == 'want_to_read' and progress.current_page > 0:
            progress.status = 'currently_reading'
            if not progress.started_at:
                progress.started_at = timezone.now()
        progress.save()
        return JsonResponse({
            'status': 'success',
            'progress_percentage': float(progress.progress_percentage),
            'is_completed': progress.status == 'completed'
        })
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=400)


@login_required
@require_POST
def add_bookmark(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    location = request.POST.get('location', 'Page 1')
    note = request.POST.get('note', '')
    color = request.POST.get('color', '#2563EB')

    bookmark = Bookmark.objects.create(
        user=request.user,
        book=book,
        location=location,
        note=note,
        color=color
    )
    return JsonResponse({
        'status': 'success',
        'bookmark_id': bookmark.id,
        'location': bookmark.location,
        'note': bookmark.note,
        'created_at': bookmark.created_at.strftime('%b %d, %H:%M')
    })


@login_required
def my_library_view(request):
    """
    Personal Digital Library categorized into shelves:
    Want to Read, Currently Reading, Completed, Favorites, and Bookmarks.
    """
    shelf = request.GET.get('shelf', 'currently_reading')
    search_q = request.GET.get('q', '').strip()

    want_to_read = ReadingProgress.objects.filter(user=request.user, status='want_to_read').select_related('book')
    currently_reading = ReadingProgress.objects.filter(user=request.user, status='currently_reading').select_related('book')
    completed = ReadingProgress.objects.filter(user=request.user, status='completed').select_related('book')
    favorites = Favorite.objects.filter(user=request.user).select_related('book')
    bookmarks = Bookmark.objects.filter(user=request.user).select_related('book')
    reading_lists = ReadingList.objects.filter(user=request.user).prefetch_related('items__book')

    if search_q:
        want_to_read = want_to_read.filter(book__title__icontains=search_q)
        currently_reading = currently_reading.filter(book__title__icontains=search_q)
        completed = completed.filter(book__title__icontains=search_q)
        favorites = favorites.filter(book__title__icontains=search_q)

    context = {
        'shelf': shelf,
        'search_q': search_q,
        'want_to_read': want_to_read,
        'currently_reading': currently_reading,
        'completed': completed,
        'favorites': favorites,
        'bookmarks': bookmarks,
        'reading_lists': reading_lists,
        'counts': {
            'want': want_to_read.count(),
            'current': currently_reading.count(),
            'done': completed.count(),
            'favs': favorites.count(),
            'bookmarks': bookmarks.count(),
        }
    }
    return render(request, 'reader/my_library.html', context)
