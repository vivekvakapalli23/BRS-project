from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.contrib import messages

from .models import Recommendation, RecommendationExplanation, UserFeedback, ModelVersion
from .engine import RecommendationEngine
from books.models import Book

@login_required
def recommendation_list(request):
    """
    Personalized AI recommendations page with explanations and interactive feedback.
    """
    recs = Recommendation.objects.filter(user=request.user, is_dismissed=False).select_related('book').prefetch_related('factors')
    if not recs.exists():
        engine = RecommendationEngine()
        recs = engine.generate_recommendations_for_user(request.user, top_k=12)

    active_model = ModelVersion.objects.filter(is_active=True).first()

    context = {
        'recommendations': recs,
        'active_model': active_model,
    }
    return render(request, 'recommendations/list.html', context)


@login_required
@require_POST
def refresh_recommendations(request):
    """
    Triggers re-generation of personalized recommendations based on updated user signals.
    """
    engine = RecommendationEngine()
    engine.generate_recommendations_for_user(request.user, top_k=12)
    messages.success(request, "Your AI recommendations have been refreshed based on your latest activity!")
    return redirect('recommendations:list')


@login_required
@require_POST
def submit_feedback(request, book_id):
    """
    Handles user feedback (like, dislike, save, not_interested) to tune model behavior.
    """
    book = get_object_or_404(Book, id=book_id)
    action = request.POST.get('action')
    if action not in ['like', 'dislike', 'save', 'rate', 'not_interested']:
        return JsonResponse({'status': 'error', 'message': 'Invalid action'}, status=400)

    feedback, _ = UserFeedback.objects.update_or_create(
        user=request.user,
        book=book,
        defaults={'action': action}
    )

    if action in ['dislike', 'not_interested']:
        # Dismiss existing recommendation if present
        Recommendation.objects.filter(user=request.user, book=book).update(is_dismissed=True)

    return JsonResponse({
        'status': 'success',
        'message': f"Feedback recorded ({action}). This helps refine your future recommendations."
    })
