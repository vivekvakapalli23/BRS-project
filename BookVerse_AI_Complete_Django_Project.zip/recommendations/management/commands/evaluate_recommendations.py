from django.core.management.base import BaseCommand
from recommendations.engine import RecommendationEngine

class Command(BaseCommand):
    help = 'Evaluates offline recommendation metrics: Precision@K, Recall@K, NDCG@K and Catalog Coverage.'

    def add_arguments(self, parser):
        parser.add_argument('--k', type=int, default=5, help='Top-K threshold for metrics.')

    def handle(self, *args, **options):
        k = options['k']
        self.stdout.write(self.style.NOTICE(f"Evaluating recommendation engine at K={k}..."))
        engine = RecommendationEngine()
        metrics = engine.evaluate_offline(k=k)
        self.stdout.write(self.style.SUCCESS(
            f"Evaluation Complete!\n"
            f"  - Precision@{k}: {metrics['precision_at_k']}\n"
            f"  - Recall@{k}:    {metrics['recall_at_k']}\n"
            f"  - NDCG@{k}:      {metrics['ndcg_at_k']}\n"
            f"  - Coverage:     {metrics['coverage_pct']}%\n"
            f"  - Evaluated:    {metrics['evaluated_users']} users"
        ))
