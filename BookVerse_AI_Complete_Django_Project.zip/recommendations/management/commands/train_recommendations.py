from django.core.management.base import BaseCommand
from recommendations.engine import RecommendationEngine

class Command(BaseCommand):
    help = 'Trains and serializes TF-IDF and Collaborative Filtering recommendation models.'

    def handle(self, *args, **options):
        self.stdout.write(self.style.NOTICE("Initializing recommendation engine training..."))
        engine = RecommendationEngine()
        result = engine.train_models()
        if result.get("status") == "success":
            self.stdout.write(self.style.SUCCESS(
                f"Successfully trained models! Processed {result.get('books_count')} books, "
                f"{result.get('interactions_count')} rating interactions. Version: {result.get('version')}"
            ))
        else:
            self.stdout.write(self.style.WARNING(result.get("message", "Model training completed with warnings.")))
