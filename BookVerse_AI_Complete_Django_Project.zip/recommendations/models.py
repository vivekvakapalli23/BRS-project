from django.db import models
from django.contrib.auth.models import User

class ModelVersion(models.Model):
    model_name = models.CharField(max_length=100)
    version = models.CharField(max_length=50)
    algorithm = models.CharField(max_length=100)
    training_samples = models.PositiveIntegerField(default=0)
    precision_at_k = models.FloatField(default=0.0)
    recall_at_k = models.FloatField(default=0.0)
    ndcg_at_k = models.FloatField(default=0.0)
    coverage_percentage = models.FloatField(default=0.0)
    trained_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ['-trained_at']

    def __str__(self):
        return f"{self.model_name} v{self.version} ({'Active' if self.is_active else 'Archived'})"


class Recommendation(models.Model):
    ALGORITHM_CHOICES = [
        ('hybrid', 'Hybrid Semantic Ranking'),
        ('content_based', 'TF-IDF Content Filtering'),
        ('collaborative', 'Collaborative Filtering (KNN)'),
        ('ontology', 'OWL Semantic Graph'),
        ('cold_start', 'Cold-Start Interest Matching'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='recommendations')
    book = models.ForeignKey('books.Book', on_delete=models.CASCADE, related_name='recommended_instances')
    score = models.FloatField(default=0.0, db_index=True)
    algorithm_type = models.CharField(max_length=50, choices=ALGORITHM_CHOICES, default='hybrid')
    explanation = models.TextField(blank=True)
    rank = models.PositiveIntegerField(default=1)
    is_dismissed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-score', 'rank']
        indexes = [
            models.Index(fields=['user', 'score']),
            models.Index(fields=['user', 'is_dismissed']),
        ]

    def __str__(self):
        return f"{self.user.username} -> {self.book.title} ({self.score:.2f})"


class RecommendationExplanation(models.Model):
    recommendation = models.ForeignKey(Recommendation, on_delete=models.CASCADE, related_name='factors')
    factor_title = models.CharField(max_length=150)
    factor_detail = models.CharField(max_length=255)
    weight = models.FloatField(default=1.0)

    def __str__(self):
        return f"{self.factor_title}: {self.factor_detail}"


class UserFeedback(models.Model):
    FEEDBACK_CHOICES = [
        ('like', 'Liked'),
        ('dislike', 'Disliked'),
        ('save', 'Saved to Library'),
        ('rate', 'Rated High'),
        ('not_interested', 'Not Interested'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='recommendation_feedback')
    book = models.ForeignKey('books.Book', on_delete=models.CASCADE, related_name='recommendation_feedbacks')
    action = models.CharField(max_length=25, choices=FEEDBACK_CHOICES)
    weight = models.FloatField(default=1.0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'book', 'action')
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.user.username} {self.action} on {self.book.title}"
