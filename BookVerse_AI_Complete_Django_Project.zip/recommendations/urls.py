from django.urls import path
from . import views

app_name = 'recommendations'

urlpatterns = [
    path('', views.recommendation_list, name='list'),
    path('refresh/', views.refresh_recommendations, name='refresh'),
    path('feedback/<int:book_id>/', views.submit_feedback, name='submit_feedback'),
]
