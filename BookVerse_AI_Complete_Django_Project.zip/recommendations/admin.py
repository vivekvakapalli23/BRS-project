from django.contrib import admin
from .models import Recommendation, RecommendationExplanation, UserFeedback, ModelVersion

@admin.register(Recommendation)
class RecommendationAdmin(admin.ModelAdmin):
    list_display = ('user', 'book', 'score', 'algorithm_type', 'rank', 'is_dismissed', 'created_at')
    list_filter = ('algorithm_type', 'is_dismissed')
    search_fields = ('user__username', 'book__title')

@admin.register(ModelVersion)
class ModelVersionAdmin(admin.ModelAdmin):
    list_display = ('model_name', 'version', 'precision_at_k', 'recall_at_k', 'ndcg_at_k', 'coverage_percentage', 'is_active', 'trained_at')

admin.site.register(RecommendationExplanation)
admin.site.register(UserFeedback)
