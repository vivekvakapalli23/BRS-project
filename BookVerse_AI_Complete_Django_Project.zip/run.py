#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
BookVerse AI - One-Click Launcher & Server Orchestrator
Cross-platform, Windows-safe launcher with port polling and auto-browser launch.
"""

import os
import sys
import time
import socket
import webbrowser
import threading
import subprocess
from pathlib import Path

# Force UTF-8 encoding on standard streams to prevent Windows charmap encoding errors
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
if hasattr(sys.stderr, 'reconfigure'):
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

# Safe clean banners without high-byte emoji crashes
BANNER = """
======================================================================
  ____             _     __     __                    _     ___ 
 | __ )  ___   ___| | __ \\ \\   / /__ _ __ ___  ___   / \\   |_ _|
 |  _ \\ / _ \\ / _ \\ |/ /  \\ \\ / / _ \\ '__/ __|/ _ \\ / _ \\   | | 
 | |_) | (_) | (_) |   <    \\ V /  __/ |  \\__ \\  __// ___ \\  | | 
 |____/ \\___/ \\___/|_|\\_\\    \\_/ \\___|_|  |___/\\___/_/   \\_\\|___|
                                                                  
  Ontology-Based Intelligent Book Recommendation Platform (v2.1.0)
======================================================================
"""

def log_step(title):
    print(f"\n[*] {title}")

def log_success(msg):
    print(f"    [+] {msg}")

def log_warn(msg):
    print(f"    [!] {msg}")

def log_err(msg):
    print(f"    [-] {msg}")

def is_port_open(host, port):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.6)
            return s.connect_ex((host, port)) == 0
    except Exception:
        return False

def wait_for_server_and_open_browser(host, port, url, max_wait=30):
    """
    Polls the port until Django is actually listening, then launches the browser.
    Ensures the user never sees 'refused to connect' or ERR_CONNECTION_REFUSED.
    """
    def _poll():
        start_time = time.time()
        while time.time() - start_time < max_wait:
            if is_port_open(host, port):
                time.sleep(0.8) # Brief settle time
                print(f"\n[+] Server is online! Launching {url} in browser...")
                try:
                    webbrowser.open(url)
                except Exception:
                    pass
                return
            time.sleep(0.5)
        print(f"\n[!] Please open your browser and navigate to {url}")

    t = threading.Thread(target=_poll, daemon=True)
    t.start()

def main():
    print(BANNER)

    # Resolve base paths
    current_dir = Path(__file__).resolve().parent
    if (current_dir / "manage.py").exists():
        project_dir = current_dir
    elif (current_dir / "book_recommendation_system" / "manage.py").exists():
        project_dir = current_dir / "book_recommendation_system"
    else:
        log_err(f"manage.py not found in {current_dir}")
        sys.exit(1)

    os.chdir(project_dir)
    manage_py = project_dir / "manage.py"
    python_bin = sys.executable

    # 0. Auto-check & ensure MySQL database exists if MySQL is running
    try:
        sys.path.insert(0, str(project_dir))
        from create_mysql_db import create_database
        create_database()
    except Exception:
        pass

    # 1. Apply Migrations
    log_step("Checking and applying database migrations...")
    try:
        subprocess.run([python_bin, str(manage_py), "migrate", "--noinput"], check=True)
        log_success("Database schema verified and up to date.")
    except Exception as e:
        log_err(f"Migration error: {e}")
        sys.exit(1)

    # 2. Check Database & Auto-Seed
    log_step("Verifying book catalog and AI models...")
    try:
        check_code = (
            "import os, django; "
            "os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings'); "
            "django.setup(); "
            "from books.models import Book; "
            "print(Book.objects.count())"
        )
        res = subprocess.run([python_bin, "-c", check_code], capture_output=True, text=True, check=True)
        book_count = int(res.stdout.strip() or "0")

        if book_count == 0 or "--seed" in sys.argv:
            log_warn("Catalog is empty. Populating demonstration books, authors & training models...")
            subprocess.run([python_bin, str(manage_py), "seed_data"], check=True)
            log_success("Seed data and recommendation models initialized.")
        else:
            log_success(f"Catalog ready with {book_count} books in database.")
    except Exception as e:
        log_warn(f"Catalog check: {e}. Executing seed_data...")
        try:
            subprocess.run([python_bin, str(manage_py), "seed_data"], check=True)
        except Exception:
            pass

    # 3. Determine Port & Start Server
    host = "127.0.0.1"
    port = 8000
    if is_port_open(host, port):
        # Port 8000 already in use, try 8080
        port = 8080
        if is_port_open(host, port):
            port = 8001

    server_url = f"http://{host}:{port}/"
    admin_url = f"http://{host}:{port}/admin-panel/"

    print("\n" + "=" * 70)
    print("  BOOKVERSE AI SERVER IS STARTING")
    print("=" * 70)
    print(f"  * Main Website:         {server_url}")
    print(f"  * Custom Admin Panel:   {admin_url}")
    print(f"  * Interactive Graph:    {server_url}ontology/graph/")
    print(f"  * AI Assistant Chat:    {server_url}assistant/")
    print(f"  * Online Reader:        {server_url}reader/library/")
    print("\n  DEMO CREDENTIALS:")
    print("  * Admin:   admin   | Password: admin123  (Full Access)")
    print("  * Reader:  alice   | Password: password123")
    print("=" * 70)
    print("  Press Ctrl + C in this terminal window to stop the server.\n")

    # Start background polling to open browser ONLY when server responds!
    wait_for_server_and_open_browser(host, port, server_url)

    # 4. Start Django development server
    try:
        subprocess.run([python_bin, str(manage_py), "runserver", f"{host}:{port}"])
    except KeyboardInterrupt:
        print("\n\n[*] BookVerse AI server shutdown gracefully. Goodbye!")

if __name__ == "__main__":
    main()
