from django.db import models
from django.contrib.auth.models import User

class UserActivityLog(models.Model):
    ACTION_CHOICES = [
        ('view_book', 'Viewed Book'),
        ('search', 'Search Query'),
        ('read_session', 'Reading Session'),
        ('favorite', 'Favorited Book'),
        ('review', 'Submitted Review'),
        ('recommendation_click', 'Clicked Recommendation'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='activity_logs', null=True, blank=True)
    action = models.CharField(max_length=50, choices=ACTION_CHOICES, db_index=True)
    book = models.ForeignKey('books.Book', on_delete=models.SET_NULL, null=True, blank=True)
    details = models.JSONField(default=dict, blank=True)
    reading_duration_seconds = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ['-created_at']
