import json
from datetime import timedelta
from django.shortcuts import render
from django.http import JsonResponse
from django.utils import timezone
from django.db.models import Count, Avg
from django.contrib.auth.models import User

from books.models import Book, Genre, ReadingProgress
from community.models import Review
from recommendations.models import Recommendation, ModelVersion

def analytics_overview(request):
    """
    Public / Authenticated platform analytics page with interactive Chart.js visualizations.
    """
    total_books = Book.objects.count()
    total_reviews = Review.objects.count()
    total_readers = ReadingProgress.objects.values('user').distinct().count()

    # Most popular genres
    top_genres = Genre.objects.annotate(b_count=Count('books')).order_by('-b_count')[:6]
    genre_names = [g.name for g in top_genres]
    genre_counts = [g.b_count for g in top_genres]

    # Rating distribution
    rating_buckets = [
        Review.objects.filter(rating=i).count() for i in range(1, 6)
    ]

    active_model = ModelVersion.objects.filter(is_active=True).first()

    context = {
        'total_books': total_books,
        'total_reviews': total_reviews,
        'total_readers': total_readers,
        'active_model': active_model,
        'genre_names_json': json.dumps(genre_names),
        'genre_counts_json': json.dumps(genre_counts),
        'rating_buckets_json': json.dumps(rating_buckets),
    }
    return render(request, 'analytics/overview.html', context)


def reading_stats_api(request):
    """
    JSON API for dynamic chart updates.
    """
    days = 14
    today = timezone.now().date()
    labels = []
    data = []
    for i in range(days - 1, -1, -1):
        d = today - timedelta(days=i)
        labels.append(d.strftime('%b %d'))
        count = ReadingProgress.objects.filter(updated_at__date=d).count()
        data.append(count)

    return JsonResponse({
        'labels': labels,
        'data': data
    })
