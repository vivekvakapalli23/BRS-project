from django.urls import path
from . import views

app_name = 'analytics'

urlpatterns = [
    path('', views.analytics_overview, name='overview'),
    path('api/reading-stats/', views.reading_stats_api, name='reading_stats_api'),
]
