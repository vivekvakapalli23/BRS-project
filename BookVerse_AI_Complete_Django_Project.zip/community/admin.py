from django.contrib import admin
from .models import Review, ReviewVote, ReviewReport, Discussion, DiscussionComment, Follower

@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('user', 'book', 'rating', 'likes_count', 'is_approved', 'created_at')
    list_filter = ('rating', 'is_approved', 'contains_spoilers')
    search_fields = ('user__username', 'book__title', 'content')

@admin.register(ReviewReport)
class ReviewReportAdmin(admin.ModelAdmin):
    list_display = ('user', 'review', 'reason', 'is_resolved', 'created_at')
    list_filter = ('reason', 'is_resolved')

admin.site.register(Discussion)
admin.site.register(DiscussionComment)
admin.site.register(ReviewVote)
admin.site.register(Follower)
