from django.urls import path
from . import views

app_name = 'community'

urlpatterns = [
    path('', views.community_home, name='index'),
    path('review/<int:book_id>/submit/', views.submit_review, name='submit_review'),
    path('review/<int:review_id>/vote/', views.vote_review, name='vote_review'),
    path('review/<int:review_id>/report/', views.report_review, name='report_review'),
    path('discussion/<int:pk>/', views.discussion_detail, name='discussion_detail'),
    path('discussion/new/<int:book_id>/', views.create_discussion, name='create_discussion'),
    path('user/<int:user_id>/follow/', views.toggle_follow, name='toggle_follow'),
]
