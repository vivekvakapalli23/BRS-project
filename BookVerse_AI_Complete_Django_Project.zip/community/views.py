from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.contrib import messages
from django.contrib.auth.models import User

from .models import Review, ReviewVote, ReviewReport, Discussion, DiscussionComment, Follower
from .forms import ReviewForm, DiscussionForm, DiscussionCommentForm, ReviewReportForm
from books.models import Book

def community_home(request):
    """
    Community hub with recent reviews, active discussions, top reviewers and active readers.
    """
    recent_reviews = Review.objects.filter(is_approved=True).select_related('user', 'book', 'user__profile').order_by('-created_at')[:10]
    discussions = Discussion.objects.select_related('user', 'book', 'user__profile').order_by('-created_at')[:8]
    active_users = User.objects.filter(is_active=True).exclude(profile__is_public_profile=False).order_by('-date_joined')[:6]

    context = {
        'recent_reviews': recent_reviews,
        'discussions': discussions,
        'active_users': active_users,
    }
    return render(request, 'community/index.html', context)


@login_required
@require_POST
def submit_review(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    review = Review.objects.filter(user=request.user, book=book).first()
    form = ReviewForm(request.POST, instance=review)
    if form.is_valid():
        review_obj = form.save(commit=False)
        review_obj.user = request.user
        review_obj.book = book
        review_obj.is_approved = True
        review_obj.save()
        messages.success(request, "Your review has been published!")
    else:
        messages.error(request, "Error submitting review. Please check the inputs.")
    return redirect('books:book_detail', slug=book.slug)


@login_required
@require_POST
def vote_review(request, review_id):
    review = get_object_or_404(Review, id=review_id)
    vote, created = ReviewVote.objects.get_or_create(user=request.user, review=review)
    if not created:
        vote.delete()
        review.likes_count = max(0, review.likes_count - 1)
        voted = False
    else:
        review.likes_count += 1
        voted = True
    review.save(update_fields=['likes_count'])
    return JsonResponse({'status': 'success', 'voted': voted, 'likes_count': review.likes_count})


@login_required
def report_review(request, review_id):
    review = get_object_or_404(Review, id=review_id)
    if request.method == 'POST':
        form = ReviewReportForm(request.POST)
        if form.is_valid():
            report = form.save(commit=False)
            report.user = request.user
            report.review = review
            report.save()
            messages.success(request, "Report submitted. Our moderation team will review it.")
            return redirect('books:book_detail', slug=review.book.slug)
    else:
        form = ReviewReportForm()
    return render(request, 'community/report_review.html', {'form': form, 'review': review})


@login_required
def discussion_detail(request, pk):
    discussion = get_object_or_404(Discussion.objects.select_related('user', 'book'), pk=pk)
    comments = discussion.comments.select_related('user', 'user__profile').all()
    if request.method == 'POST':
        form = DiscussionCommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.user = request.user
            comment.discussion = discussion
            comment.save()
            messages.success(request, "Your reply was posted!")
            return redirect('community:discussion_detail', pk=discussion.pk)
    else:
        form = DiscussionCommentForm()
    return render(request, 'community/discussion_detail.html', {
        'discussion': discussion,
        'comments': comments,
        'form': form
    })


@login_required
def create_discussion(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    if request.method == 'POST':
        form = DiscussionForm(request.POST)
        if form.is_valid():
            discussion = form.save(commit=False)
            discussion.user = request.user
            discussion.book = book
            discussion.save()
            messages.success(request, "Discussion thread created!")
            return redirect('community:discussion_detail', pk=discussion.pk)
    else:
        form = DiscussionForm()
    return render(request, 'community/create_discussion.html', {'form': form, 'book': book})


@login_required
@require_POST
def toggle_follow(request, user_id):
    target_user = get_object_or_404(User, id=user_id)
    if target_user == request.user:
        return JsonResponse({'status': 'error', 'message': 'You cannot follow yourself.'}, status=400)

    follow, created = Follower.objects.get_or_create(user=request.user, followed_user=target_user)
    if not created:
        follow.delete()
        is_following = False
    else:
        is_following = True
    return JsonResponse({'status': 'success', 'is_following': is_following})
