from django.urls import path
from . import views

app_name = 'ontology'

urlpatterns = [
    path('graph/', views.knowledge_graph_view, name='knowledge_graph'),
    path('api/graph-data/', views.graph_data_api, name='graph_data_api'),
    path('generate/', views.generate_ontology_view, name='generate_ontology'),
    path('download/owl/', views.download_owl_view, name='download_owl'),
    path('download/ttl/', views.download_ttl_view, name='download_ttl'),
]
