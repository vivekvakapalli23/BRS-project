from pathlib import Path
from django.conf import settings
from rdflib import Graph, Namespace, URIRef
from books.models import Book, Genre, Author

BV = Namespace("http://bookverse.ai/ontology#")

def get_loaded_graph():
    ttl_path = Path(settings.ONTOLOGY_FILES_DIR) / "bookverse.ttl"
    g = Graph()
    if ttl_path.exists():
        try:
            g.parse(str(ttl_path), format="turtle")
        except Exception:
            pass
    return g

def query_ontology_similar_books(book_id, limit=6):
    """
    SPARQL-based reasoning to find books sharing authors, genres or subjects.
    """
    g = get_loaded_graph()
    if len(g) == 0:
        # Fallback to ORM if ontology graph is empty
        book = Book.objects.filter(id=book_id).first()
        if not book:
            return []
        return list(Book.objects.filter(genres__in=book.genres.all()).exclude(id=book.id).distinct()[:limit])

    query = f"""
    PREFIX bv: <http://bookverse.ai/ontology#>
    SELECT DISTINCT ?targetBook (COUNT(?common) as ?score)
    WHERE {{
        <http://bookverse.ai/ontology#Book_{book_id}> ?prop ?common .
        ?targetBook ?prop ?common .
        FILTER(?targetBook != <http://bookverse.ai/ontology#Book_{book_id}>)
        FILTER(?prop IN (bv:hasGenre, bv:writtenBy, bv:hasSubject))
    }}
    GROUP BY ?targetBook
    ORDER BY DESC(?score)
    LIMIT {limit}
    """
    results = g.query(query)
    book_ids = []
    for row in results:
        target_uri = str(row[0])
        if "Book_" in target_uri:
            try:
                b_id = int(target_uri.split("Book_")[-1])
                book_ids.append(b_id)
            except ValueError:
                pass
    
    if not book_ids:
        book = Book.objects.filter(id=book_id).first()
        if book:
            return list(Book.objects.filter(genres__in=book.genres.all()).exclude(id=book.id).distinct()[:limit])
        return []

    found_books = list(Book.objects.filter(id__in=book_ids))
    # Retain score order
    found_books.sort(key=lambda b: book_ids.index(b.id) if b.id in book_ids else 999)
    return found_books


def get_cytoscape_elements(max_nodes=150):
    """
    Produces Cytoscape.js compatible JSON nodes and edges from database models.
    """
    elements = []
    node_ids = set()

    books = Book.objects.all().prefetch_related('authors', 'genres')[:25]
    for b in books:
        b_node_id = f"book_{b.id}"
        if b_node_id not in node_ids:
            elements.append({
                'data': {
                    'id': b_node_id,
                    'label': b.title[:24] + ('...' if len(b.title) > 24 else ''),
                    'type': 'Book',
                    'color': '#2563EB',
                    'rating': float(b.average_rating),
                    'slug': b.slug,
                }
            })
            node_ids.add(b_node_id)

        for a in b.authors.all()[:2]:
            a_node_id = f"author_{a.id}"
            if a_node_id not in node_ids:
                elements.append({
                    'data': {
                        'id': a_node_id,
                        'label': a.name,
                        'type': 'Author',
                        'color': '#1E3A8A',
                    }
                })
                node_ids.add(a_node_id)
            elements.append({
                'data': {
                    'id': f"edge_{b_node_id}_{a_node_id}",
                    'source': b_node_id,
                    'target': a_node_id,
                    'relation': 'writtenBy',
                }
            })

        for g in b.genres.all()[:3]:
            g_node_id = f"genre_{g.id}"
            if g_node_id not in node_ids:
                elements.append({
                    'data': {
                        'id': g_node_id,
                        'label': g.name,
                        'type': 'Genre',
                        'color': '#10B981',
                    }
                })
                node_ids.add(g_node_id)
            elements.append({
                'data': {
                    'id': f"edge_{b_node_id}_{g_node_id}",
                    'source': b_node_id,
                    'target': g_node_id,
                    'relation': 'hasGenre',
                }
            })

    return elements
