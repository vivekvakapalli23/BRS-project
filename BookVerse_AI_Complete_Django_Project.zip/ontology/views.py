from django.shortcuts import render, redirect
from django.http import JsonResponse, FileResponse, Http404
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib import messages
from pathlib import Path
from django.conf import settings

from .models import OntologyMetadata
from .generator import generate_bookverse_ontology
from .services import get_cytoscape_elements, query_ontology_similar_books
from books.models import Book

def knowledge_graph_view(request):
    """
    Cytoscape.js interactive knowledge graph explorer.
    """
    meta = OntologyMetadata.objects.first()
    context = {
        'meta': meta,
    }
    return render(request, 'ontology/graph.html', context)

def graph_data_api(request):
    """
    Returns Cytoscape JSON graph elements.
    """
    elements = get_cytoscape_elements()
    return JsonResponse({'elements': elements})

@staff_member_required
def generate_ontology_view(request):
    try:
        result = generate_bookverse_ontology()
        messages.success(request, f"Ontology rebuilt successfully! {result['triples_count']} triples generated.")
    except Exception as e:
        messages.error(request, f"Failed to generate ontology: {str(e)}")
    return redirect('custom_admin:admin_dashboard')

def download_owl_view(request):
    path = Path(settings.ONTOLOGY_FILES_DIR) / "bookverse.owl"
    if path.exists():
        return FileResponse(open(path, 'rb'), as_attachment=True, filename='bookverse.owl')
    raise Http404("Ontology OWL file not yet generated.")

def download_ttl_view(request):
    path = Path(settings.ONTOLOGY_FILES_DIR) / "bookverse.ttl"
    if path.exists():
        return FileResponse(open(path, 'rb'), as_attachment=True, filename='bookverse.ttl')
    raise Http404("Ontology Turtle file not yet generated.")
