from django.db import models

class OntologyMetadata(models.Model):
    name = models.CharField(max_length=150, default="BookVerse Knowledge Ontology")
    version = models.CharField(max_length=50, default="1.0.0")
    namespace = models.CharField(max_length=255, default="http://bookverse.ai/ontology#")
    triples_count = models.PositiveIntegerField(default=0)
    classes_count = models.PositiveIntegerField(default=11)
    properties_count = models.PositiveIntegerField(default=10)
    owl_file = models.FileField(upload_to='ontology/', blank=True, null=True)
    turtle_file = models.FileField(upload_to='ontology/', blank=True, null=True)
    generated_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)
    summary = models.TextField(blank=True)

    class Meta:
        ordering = ['-generated_at']

    def __str__(self):
        return f"{self.name} v{self.version} ({self.triples_count} triples)"
