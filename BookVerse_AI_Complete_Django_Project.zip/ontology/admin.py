from django.contrib import admin
from .models import OntologyMetadata

@admin.register(OntologyMetadata)
class OntologyMetadataAdmin(admin.ModelAdmin):
    list_display = ('name', 'version', 'triples_count', 'classes_count', 'properties_count', 'generated_at', 'is_active')
