import os
from pathlib import Path
from django.conf import settings
from rdflib import Graph, Literal, RDF, RDFS, OWL, Namespace, URIRef
from rdflib.namespace import XSD

# Namespace definition
BV = Namespace("http://bookverse.ai/ontology#")

def generate_bookverse_ontology():
    """
    Constructs an OWL 2 ontology representing the BookVerse AI domain.
    Serializes to both RDF/XML (.owl) and Turtle (.ttl) files.
    Returns metadata dict.
    """
    g = Graph()
    g.bind("bv", BV)
    g.bind("owl", OWL)
    g.bind("rdfs", RDFS)
    g.bind("xsd", XSD)

    # 1. Define Ontology URI
    ontology_uri = URIRef("http://bookverse.ai/ontology")
    g.add((ontology_uri, RDF.type, OWL.Ontology))
    g.add((ontology_uri, RDFS.label, Literal("BookVerse AI Knowledge Graph Ontology", lang="en")))
    g.add((ontology_uri, RDFS.comment, Literal("Ontology for intelligent book discovery, author relations and reader semantics.", lang="en")))

    # 2. Define OWL Classes
    classes = [
        "Book", "Author", "Genre", "Subject", "Publisher",
        "Language", "User", "Interest", "Rating", "Review", "ReadingHistory"
    ]
    for cls_name in classes:
        cls_uri = BV[cls_name]
        g.add((cls_uri, RDF.type, OWL.Class))
        g.add((cls_uri, RDFS.label, Literal(cls_name, lang="en")))

    # 3. Define Object Properties
    properties = [
        ("writtenBy", "Book", "Author"),
        ("hasGenre", "Book", "Genre"),
        ("hasSubject", "Book", "Subject"),
        ("publishedBy", "Book", "Publisher"),
        ("hasLanguage", "Book", "Language"),
        ("interestedIn", "User", "Genre"),
        ("hasRead", "User", "Book"),
        ("likesBook", "User", "Book"),
        ("ratedBook", "User", "Book"),
        ("similarTo", "Book", "Book"),
    ]
    for prop_name, domain, range_cls in properties:
        prop_uri = BV[prop_name]
        g.add((prop_uri, RDF.type, OWL.ObjectProperty))
        g.add((prop_uri, RDFS.label, Literal(prop_name, lang="en")))
        g.add((prop_uri, RDFS.domain, BV[domain]))
        g.add((prop_uri, RDFS.range, BV[range_cls]))

    # similarTo is symmetric
    g.add((BV.similarTo, RDF.type, OWL.SymmetricProperty))

    # 4. Populate with actual database records
    from books.models import Book, Author, Genre, Subject, Publisher, Favorite, ReadingProgress
    from community.models import Review
    from accounts.models import UserProfile
    from django.contrib.auth.models import User

    # Authors
    for author in Author.objects.all():
        author_uri = BV[f"Author_{author.id}"]
        g.add((author_uri, RDF.type, BV.Author))
        g.add((author_uri, RDFS.label, Literal(author.name)))
        if author.birth_year:
            g.add((author_uri, BV.birthYear, Literal(author.birth_year, datatype=XSD.integer)))

    # Genres
    for genre in Genre.objects.all():
        genre_uri = BV[f"Genre_{genre.id}"]
        g.add((genre_uri, RDF.type, BV.Genre))
        g.add((genre_uri, RDFS.label, Literal(genre.name)))

    # Publishers
    for pub in Publisher.objects.all():
        pub_uri = BV[f"Publisher_{pub.id}"]
        g.add((pub_uri, RDF.type, BV.Publisher))
        g.add((pub_uri, RDFS.label, Literal(pub.name)))

    # Books and relations
    for book in Book.objects.all().prefetch_related('authors', 'genres', 'subjects'):
        book_uri = BV[f"Book_{book.id}"]
        g.add((book_uri, RDF.type, BV.Book))
        g.add((book_uri, RDFS.label, Literal(book.title)))
        g.add((book_uri, BV.rating, Literal(float(book.average_rating), datatype=XSD.float)))
        if book.publication_year:
            g.add((book_uri, BV.year, Literal(book.publication_year, datatype=XSD.integer)))

        for author in book.authors.all():
            g.add((book_uri, BV.writtenBy, BV[f"Author_{author.id}"]))

        for genre in book.genres.all():
            g.add((book_uri, BV.hasGenre, BV[f"Genre_{genre.id}"]))

        for subject in book.subjects.all():
            subj_uri = BV[f"Subject_{subject.id}"]
            g.add((subj_uri, RDF.type, BV.Subject))
            g.add((subj_uri, RDFS.label, Literal(subject.name)))
            g.add((book_uri, BV.hasSubject, subj_uri))

        if book.publisher:
            g.add((book_uri, BV.publishedBy, BV[f"Publisher_{book.publisher.id}"]))

    # Users and interactions
    for profile in UserProfile.objects.select_related('user').prefetch_related('preferred_genres'):
        user_uri = BV[f"User_{profile.user.id}"]
        g.add((user_uri, RDF.type, BV.User))
        g.add((user_uri, RDFS.label, Literal(profile.user.username)))
        for g_pref in profile.preferred_genres.all():
            g.add((user_uri, BV.interestedIn, BV[f"Genre_{g_pref.id}"]))

    for fav in Favorite.objects.select_related('user', 'book'):
        g.add((BV[f"User_{fav.user.id}"], BV.likesBook, BV[f"Book_{fav.book.id}"]))

    for prog in ReadingProgress.objects.filter(status='completed').select_related('user', 'book'):
        g.add((BV[f"User_{prog.user.id}"], BV.hasRead, BV[f"Book_{prog.book.id}"]))

    for rev in Review.objects.select_related('user', 'book'):
        g.add((BV[f"User_{rev.user.id}"], BV.ratedBook, BV[f"Book_{rev.book.id}"]))

    # Save to disk
    out_dir = Path(settings.ONTOLOGY_FILES_DIR)
    out_dir.mkdir(parents=True, exist_ok=True)
    owl_path = out_dir / "bookverse.owl"
    ttl_path = out_dir / "bookverse.ttl"

    g.serialize(destination=str(owl_path), format="xml")
    g.serialize(destination=str(ttl_path), format="turtle")

    from .models import OntologyMetadata
    meta, _ = OntologyMetadata.objects.get_or_create(name="BookVerse Knowledge Ontology")
    meta.triples_count = len(g)
    meta.classes_count = len(classes)
    meta.properties_count = len(properties)
    meta.summary = f"Generated with {len(g)} triples connecting Books, Authors, Genres, Users and Reviews."
    meta.save()

    return {
        'triples_count': len(g),
        'classes_count': len(classes),
        'properties_count': len(properties),
        'owl_path': str(owl_path),
        'ttl_path': str(ttl_path),
    }
