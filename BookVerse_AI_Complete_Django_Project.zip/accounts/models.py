from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    display_name = models.CharField(max_length=100, blank=True)
    bio = models.TextField(blank=True, max_length=500)
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)
    avatar_url = models.URLField(blank=True, max_length=500)
    preferred_genres = models.ManyToManyField('books.Genre', blank=True, related_name='interested_users')
    preferred_languages = models.CharField(max_length=100, default='English')
    reading_goal_annual = models.PositiveIntegerField(default=12)
    dark_mode = models.BooleanField(default=False)
    reading_streak_days = models.PositiveIntegerField(default=0)
    last_read_date = models.DateField(null=True, blank=True)
    email_notifications = models.BooleanField(default=True)
    is_public_profile = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'User Profile'
        verbose_name_plural = 'User Profiles'

    def __str__(self):
        return f"{self.display_name or self.user.username}'s Profile"

    @property
    def get_avatar_url(self):
        if self.avatar:
            return self.avatar.url
        if self.avatar_url:
            return self.avatar_url
        # Premium fallback SVG or UI Avatars
        name = self.display_name or self.user.username
        return f"https://ui-avatars.com/api/?name={name}&background=2563EB&color=ffffff&bold=true"

    def update_streak(self):
        today = timezone.now().date()
        if self.last_read_date:
            delta = (today - self.last_read_date).days
            if delta == 1:
                self.reading_streak_days += 1
            elif delta > 1:
                self.reading_streak_days = 1
        else:
            self.reading_streak_days = 1
        self.last_read_date = today
        self.save(update_fields=['reading_streak_days', 'last_read_date'])
