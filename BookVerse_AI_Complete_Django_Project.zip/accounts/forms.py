from django import forms
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.utils.text import slugify
from .models import UserProfile
from books.models import Genre

class UserRegisterForm(UserCreationForm):
    full_name = forms.CharField(
        max_length=120,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter your full name'
        })
    )
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter your email'
        })
    )
    terms = forms.BooleanField(
        required=False,
        initial=True
    )

    class Meta:
        model = User
        fields = ('full_name', 'email')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if 'password1' in self.fields:
            self.fields['password1'].widget.attrs.update({
                'class': 'form-control',
                'placeholder': 'Create a password'
            })
        if 'password2' in self.fields:
            self.fields['password2'].required = False

    def clean_email(self):
        email = self.cleaned_data.get('email', '').strip().lower()
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError("A user with this email address already exists.")
        return email

    def clean(self):
        cleaned_data = super().clean()
        pw1 = cleaned_data.get('password1')
        pw2 = cleaned_data.get('password2')
        if pw1 and not pw2:
            cleaned_data['password2'] = pw1
            self.cleaned_data['password2'] = pw1
            if 'password2' in self._errors:
                del self._errors['password2']
        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']

        # Parse full name
        full_name = self.cleaned_data.get('full_name', '').strip()
        parts = full_name.split(maxsplit=1)
        user.first_name = parts[0] if parts else ''
        user.last_name = parts[1] if len(parts) > 1 else ''

        # Auto-generate unique username from email/full_name
        base_username = slugify(parts[0] if parts else user.email.split('@')[0]) or 'reader'
        username = base_username
        counter = 1
        while User.objects.filter(username=username).exists():
            username = f"{base_username}{counter}"
            counter += 1
        user.username = username

        if commit:
            user.save()
            if hasattr(user, 'profile'):
                user.profile.display_name = full_name
                user.profile.save()
        return user


class UserLoginForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'form-control',
        'placeholder': 'Enter your email'
    }))
    password = forms.CharField(widget=forms.PasswordInput(attrs={
        'class': 'form-control',
        'placeholder': 'Enter your password'
    }))

    def clean(self):
        username = self.cleaned_data.get('username')
        password = self.cleaned_data.get('password')

        if username and password:
            # Check if user entered an email
            if '@' in username:
                user_match = User.objects.filter(email__iexact=username.strip()).first()
                if user_match:
                    username = user_match.username
                    self.cleaned_data['username'] = username

            self.user_cache = authenticate(self.request, username=username, password=password)
            if self.user_cache is None:
                raise self.get_invalid_login_error()
            else:
                self.confirm_login_allowed(self.user_cache)

        return self.cleaned_data


class UserProfileUpdateForm(forms.ModelForm):
    first_name = forms.CharField(max_length=50, required=False, widget=forms.TextInput(attrs={'class': 'form-control'}))
    last_name = forms.CharField(max_length=50, required=False, widget=forms.TextInput(attrs={'class': 'form-control'}))
    email = forms.EmailField(required=True, widget=forms.EmailInput(attrs={'class': 'form-control'}))

    class Meta:
        model = UserProfile
        fields = ('display_name', 'avatar', 'bio', 'preferred_languages', 'preferred_genres', 'reading_goal_annual')
        widgets = {
            'bio': forms.Textarea(attrs={'rows': 3, 'class': 'form-control'}),
            'display_name': forms.TextInput(attrs={'class': 'form-control'}),
            'preferred_languages': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. English, Telugu, Spanish'}),
            'reading_goal_annual': forms.NumberInput(attrs={'class': 'form-control'}),
            'preferred_genres': forms.CheckboxSelectMultiple(),
        }
