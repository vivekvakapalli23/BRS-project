from django.contrib import admin
from .models import UserProfile

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'display_name', 'reading_goal_annual', 'reading_streak_days', 'dark_mode')
    search_fields = ('user__username', 'user__email', 'display_name')
    list_filter = ('dark_mode', 'is_public_profile', 'email_notifications')
