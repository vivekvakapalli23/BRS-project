from django.shortcuts import render, get_object_or_404, redirect
from django.core.paginator import Paginator
from django.db.models import Q, Avg, Count
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.contrib import messages

from .models import Book, Author, Genre, Subject, Publisher, Favorite, ReadingProgress, ReadingGoal
from community.models import Review
from recommendations.models import Recommendation

def home_view(request):
    """
    BookVerse AI Landing & Discovery Page.
    """
    trending_books = Book.objects.filter(is_trending=True)[:8]
    if not trending_books.exists():
        trending_books = Book.objects.order_by('-view_count')[:8]

    popular_books = Book.objects.filter(is_featured=True)[:8]
    if not popular_books.exists():
        popular_books = Book.objects.order_by('-ratings_count')[:8]

    top_rated_books = Book.objects.order_by('-average_rating', '-ratings_count')[:8]
    new_arrivals = Book.objects.order_by('-created_at')[:8]
    genres = Genre.objects.annotate(book_count=Count('books')).order_by('-book_count')[:12]
    featured_authors = Author.objects.annotate(book_count=Count('books')).order_by('-book_count')[:6]

    # Personalized or smart fallback recommendations
    recommended_books = []
    if request.user.is_authenticated:
        recs = Recommendation.objects.filter(user=request.user, is_dismissed=False).select_related('book')[:8]
        if recs.exists():
            recommended_books = [r.book for r in recs]
    
    if not recommended_books:
        # High quality fallback
        recommended_books = Book.objects.order_by('-average_rating')[:8]

    context = {
        'trending_books': trending_books,
        'popular_books': popular_books,
        'top_rated_books': top_rated_books,
        'new_arrivals': new_arrivals,
        'genres': genres,
        'featured_authors': featured_authors,
        'recommended_books': recommended_books,
    }
    return render(request, 'books/home.html', context)


def explore_books(request):
    """
    Catalog exploration with multi-facet filtering, dynamic sorting, search, and pagination.
    """
    books = Book.objects.all().prefetch_related('authors', 'genres')

    q = request.GET.get('q', '').strip()
    genre_slug = request.GET.get('genre', '').strip()
    author_id = request.GET.get('author', '').strip()
    min_rating = request.GET.get('rating', '').strip()
    sort = request.GET.get('sort', 'popular')
    view_mode = request.GET.get('view', 'grid')

    if q:
        books = books.filter(
            Q(title__icontains=q) |
            Q(description__icontains=q) |
            Q(authors__name__icontains=q) |
            Q(genres__name__icontains=q) |
            Q(isbn__icontains=q)
        ).distinct()

    if genre_slug:
        books = books.filter(genres__slug=genre_slug)

    if author_id:
        books = books.filter(authors__id=author_id)

    if min_rating:
        try:
            rating_val = float(min_rating)
            books = books.filter(average_rating__gte=rating_val)
        except ValueError:
            pass

    # Sorting options
    if sort == 'rating':
        books = books.order_by('-average_rating', '-ratings_count')
    elif sort == 'newest':
        books = books.order_by('-publication_year', '-created_at')
    elif sort == 'title_asc':
        books = books.order_by('title')
    elif sort == 'title_desc':
        books = books.order_by('-title')
    else:  # popular
        books = books.order_by('-ratings_count', '-view_count', '-average_rating')

    paginator = Paginator(books, 12)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    all_genres = Genre.objects.all()
    all_authors = Author.objects.all()[:30]

    # Pre-fetch user favorites and reading progress if authenticated
    user_favorites = set()
    user_progress_map = {}
    if request.user.is_authenticated:
        user_favorites = set(Favorite.objects.filter(user=request.user).values_list('book_id', flat=True))
        progress_qs = ReadingProgress.objects.filter(user=request.user)
        for p in progress_qs:
            user_progress_map[p.book_id] = p.status

    context = {
        'page_obj': page_obj,
        'q': q,
        'genre_slug': genre_slug,
        'author_id': author_id,
        'min_rating': min_rating,
        'sort': sort,
        'view_mode': view_mode,
        'all_genres': all_genres,
        'all_authors': all_authors,
        'user_favorites': user_favorites,
        'user_progress_map': user_progress_map,
        'total_count': paginator.count,
    }
    return render(request, 'books/explore.html', context)


def book_detail(request, slug):
    """
    Detailed book view with reviews, semantic similarity, reading actions and explanations.
    """
    book = get_object_or_404(
        Book.objects.prefetch_related('authors', 'genres', 'subjects'),
        slug=slug
    )

    # Increment view count
    Book.objects.filter(pk=book.pk).update(view_count=book.view_count + 1)

    # Check user state
    is_favorite = False
    reading_status = None
    user_review = None
    if request.user.is_authenticated:
        is_favorite = Favorite.objects.filter(user=request.user, book=book).exists()
        progress = ReadingProgress.objects.filter(user=request.user, book=book).first()
        if progress:
            reading_status = progress.status
        user_review = Review.objects.filter(user=request.user, book=book).first()

    # Similar books based on shared genres and author
    similar_books = Book.objects.filter(
        genres__in=book.genres.all()
    ).exclude(id=book.id).distinct().order_by('-average_rating')[:6]

    # Active reviews
    reviews = Review.objects.filter(book=book, is_approved=True).select_related('user', 'user__profile').order_by('-created_at')

    # Recommendation explanation if recommended to this user
    explanation = None
    if request.user.is_authenticated:
        rec = Recommendation.objects.filter(user=request.user, book=book).first()
        if rec:
            explanation = rec.explanation

    context = {
        'book': book,
        'is_favorite': is_favorite,
        'reading_status': reading_status,
        'user_review': user_review,
        'similar_books': similar_books,
        'reviews': reviews,
        'explanation': explanation,
    }
    return render(request, 'books/book_detail.html', context)


@login_required
@require_POST
def toggle_favorite(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    fav, created = Favorite.objects.get_or_create(user=request.user, book=book)
    if not created:
        fav.delete()
        is_fav = False
        msg = f"Removed '{book.title}' from your favorites."
    else:
        is_fav = True
        msg = f"Added '{book.title}' to your favorites."
    
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({'status': 'success', 'is_favorite': is_fav, 'message': msg})
    messages.success(request, msg)
    return redirect(request.META.get('HTTP_REFERER', 'books:explore'))


@login_required
@require_POST
def update_reading_status(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    new_status = request.POST.get('status', 'want_to_read')
    if new_status not in ['want_to_read', 'currently_reading', 'completed', 'remove']:
        return JsonResponse({'status': 'error', 'message': 'Invalid status'}, status=400)

    if new_status == 'remove':
        ReadingProgress.objects.filter(user=request.user, book=book).delete()
        msg = f"Removed '{book.title}' from your reading shelf."
        current_status = None
    else:
        progress, created = ReadingProgress.objects.get_or_create(
            user=request.user,
            book=book,
            defaults={'total_pages': book.page_count, 'status': new_status}
        )
        if not created:
            progress.status = new_status
            progress.save()
        msg = f"Updated '{book.title}' to {progress.get_status_display()}."
        current_status = progress.status

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({'status': 'success', 'reading_status': current_status, 'message': msg})
    messages.success(request, msg)
    return redirect(request.META.get('HTTP_REFERER', 'books:explore'))


def author_detail(request, slug):
    author = get_object_or_404(Author, slug=slug)
    books = author.books.all().order_by('-average_rating')
    return render(request, 'books/author_detail.html', {'author': author, 'books': books})


def genre_detail(request, slug):
    genre = get_object_or_404(Genre, slug=slug)
    books = genre.books.all().order_by('-average_rating')
    paginator = Paginator(books, 12)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'books/genre_detail.html', {'genre': genre, 'page_obj': page_obj})
