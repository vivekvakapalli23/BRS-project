from django.urls import path
from . import views

app_name = 'books'

urlpatterns = [
    path('', views.home_view, name='home'),
    path('explore/', views.explore_books, name='explore'),
    path('book/<slug:slug>/', views.book_detail, name='book_detail'),
    path('book/<int:book_id>/toggle-favorite/', views.toggle_favorite, name='toggle_favorite'),
    path('book/<int:book_id>/update-status/', views.update_reading_status, name='update_reading_status'),
    path('author/<slug:slug>/', views.author_detail, name='author_detail'),
    path('genre/<slug:slug>/', views.genre_detail, name='genre_detail'),
]
