from django.contrib import admin
from .models import Author, Genre, Subject, Publisher, Book, Favorite, ReadingProgress, ReadingList, ReadingListItem, Bookmark, ReadingGoal

@admin.register(Author)
class AuthorAdmin(admin.ModelAdmin):
    list_display = ('name', 'birth_year', 'created_at')
    search_fields = ('name',)
    prepopulated_fields = {'slug': ('name',)}

@admin.register(Genre)
class GenreAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug', 'icon')
    prepopulated_fields = {'slug': ('name',)}

@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'publication_year', 'average_rating', 'ratings_count', 'is_featured', 'is_trending')
    list_filter = ('is_featured', 'is_trending', 'genres', 'language')
    search_fields = ('title', 'isbn', 'authors__name')
    prepopulated_fields = {'slug': ('title',)}

admin.site.register(Publisher)
admin.site.register(Subject)
admin.site.register(Favorite)
admin.site.register(ReadingProgress)
admin.site.register(ReadingList)
admin.site.register(ReadingListItem)
admin.site.register(Bookmark)
admin.site.register(ReadingGoal)
