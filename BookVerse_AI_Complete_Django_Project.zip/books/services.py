import logging
import requests
from django.core.cache import cache

logger = logging.getLogger(__name__)

OPEN_LIBRARY_SEARCH_URL = "https://openlibrary.org/search.json"
OPEN_LIBRARY_WORKS_URL = "https://openlibrary.org"

def search_open_library(query, limit=10):
    """
    Search Open Library by query (title, author, keyword) with timeout & error handling.
    """
    cache_key = f"ol_search_{query}_{limit}"
    cached_result = cache.get(cache_key)
    if cached_result:
        return cached_result

    try:
        response = requests.get(
            OPEN_LIBRARY_SEARCH_URL,
            params={'q': query, 'limit': limit},
            timeout=5
        )
        if response.status_code == 200:
            data = response.json()
            docs = data.get('docs', [])
            results = []
            for doc in docs:
                cover_id = doc.get('cover_i')
                cover_url = f"https://covers.openlibrary.org/b/id/{cover_id}-L.jpg" if cover_id else ""
                results.append({
                    'title': doc.get('title', 'Unknown Title'),
                    'authors': doc.get('author_name', ['Unknown']),
                    'publication_year': doc.get('first_publish_year'),
                    'isbn': doc.get('isbn', [None])[0] if doc.get('isbn') else '',
                    'cover_url': cover_url,
                    'key': doc.get('key', ''),
                    'subjects': doc.get('subject', [])[:5],
                })
            cache.set(cache_key, results, timeout=3600)
            return results
    except Exception as e:
        logger.warning(f"Open Library search error: {e}")
    
    return []

def fetch_open_library_book_details(work_key):
    """
    Fetch detailed metadata for a work from Open Library.
    """
    if not work_key:
        return None
    
    clean_key = work_key if work_key.startswith('/') else f"/works/{work_key}"
    url = f"https://openlibrary.org{clean_key}.json"
    cache_key = f"ol_work_{clean_key}"
    cached = cache.get(cache_key)
    if cached:
        return cached

    try:
        response = requests.get(url, timeout=5)
        if response.status_code == 200:
            data = response.json()
            desc = data.get('description', '')
            if isinstance(desc, dict):
                desc = desc.get('value', '')
            details = {
                'title': data.get('title'),
                'description': desc,
                'subjects': data.get('subjects', [])[:10],
            }
            cache.set(cache_key, details, timeout=86400)
            return details
    except Exception as e:
        logger.warning(f"Open Library fetch error: {e}")

    return None
