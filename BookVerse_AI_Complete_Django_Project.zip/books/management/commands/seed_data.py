from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from django.utils import timezone
from datetime import timedelta
import random

from accounts.models import UserProfile
from books.models import Author, Genre, Publisher, Subject, Book, Favorite, ReadingProgress, ReadingGoal, Bookmark
from community.models import Review, Discussion, DiscussionComment
from notifications.models import Notification
from ontology.generator import generate_bookverse_ontology
from recommendations.engine import RecommendationEngine

class Command(BaseCommand):
    help = 'Seeds realistic demonstration data for BookVerse AI platform.'

    def handle(self, *args, **options):
        self.stdout.write(self.style.NOTICE("Starting BookVerse AI database seeding..."))

        # 1. Superuser
        admin_user, created = User.objects.get_or_create(username='admin', defaults={'email': 'admin@bookverse.ai', 'is_staff': True, 'is_superuser': True})
        if created:
            admin_user.set_password('admin123')
            admin_user.save()
            self.stdout.write(self.style.SUCCESS("Created superuser: admin / admin123"))

        # 2. Demo Users
        users_data = [
            ("alice", "alice@bookverse.ai", "Alice Chen", "Passionate speculative fiction and artificial intelligence enthusiast.", 15, 7),
            ("bob", "bob@bookverse.ai", "Robert Vance", "History buff, philosopher, and classical literature scholar.", 20, 14),
            ("charlie", "charlie@bookverse.ai", "Charlie Davis", "Lover of thrilling noir mysteries and cyberpunk worldbuilding.", 12, 3),
            ("diana", "diana@bookverse.ai", "Diana Prince", "Curating modern psychological fiction and evolutionary biology.", 24, 21),
            ("elena", "elena@bookverse.ai", "Elena Rostova", "Exploring dystopian politics, philosophy, and cognitive science.", 18, 12),
        ]

        users = {}
        for username, email, full_name, bio, goal, streak in users_data:
            u, c = User.objects.get_or_create(username=username, defaults={'email': email, 'first_name': full_name.split()[0], 'last_name': full_name.split()[-1]})
            if c:
                u.set_password('password123')
                u.save()
            profile = u.profile
            profile.display_name = full_name
            profile.bio = bio
            profile.reading_goal_annual = goal
            profile.reading_streak_days = streak
            profile.last_read_date = timezone.now().date()
            profile.save()
            users[username] = u

        # 3. Genres
        genres_data = [
            ("Science Fiction", "bi-rocket-takeoff", "Exploration of visionary science, future technologies, and space travel."),
            ("Dystopian", "bi-building-exclamation", "Societies characterized by oppressive societal control or post-apocalyptic survival."),
            ("Classic Literature", "bi-journal-bookmark", "Time-tested masterworks of enduring historical and aesthetic value."),
            ("Philosophy", "bi-lightbulb", "Fundamental questions regarding existence, reason, knowledge, and morality."),
            ("Mystery & Thriller", "bi-search", "Fast-paced investigative puzzles, crime noir, and suspenseful twists."),
            ("Fantasy", "bi-magic", "Imaginative mythologies, magical realism, and epic adventures."),
            ("Psychology", "bi-diagram-3", "The study of mind, human behavior, decision-making, and consciousness."),
            ("Technology & AI", "bi-cpu", "Computing foundations, artificial intelligence, and our digital future."),
        ]

        genres = {}
        for name, icon, desc in genres_data:
            g, _ = Genre.objects.get_or_create(name=name, defaults={'icon': icon, 'description': desc})
            genres[name] = g

        # Assign preferred genres to users
        users['alice'].profile.preferred_genres.set([genres['Science Fiction'], genres['Technology & AI'], genres['Dystopian']])
        users['bob'].profile.preferred_genres.set([genres['Classic Literature'], genres['Philosophy']])
        users['charlie'].profile.preferred_genres.set([genres['Mystery & Thriller'], genres['Science Fiction']])
        users['diana'].profile.preferred_genres.set([genres['Psychology'], genres['Classic Literature']])
        users['elena'].profile.preferred_genres.set([genres['Dystopian'], genres['Philosophy']])

        # 4. Publishers
        publishers_data = [
            ("Penguin Classics", "London, UK"),
            ("HarperCollins", "New York, USA"),
            ("Oxford University Press", "Oxford, UK"),
            ("Vintage Books", "New York, USA"),
            ("Tor Books", "New York, USA"),
        ]
        publishers = {}
        for name, loc in publishers_data:
            p, _ = Publisher.objects.get_or_create(name=name, defaults={'location': loc})
            publishers[name] = p

        # 5. Authors
        authors_data = [
            ("George Orwell", 1903, "English novelist, essayist, and critic famous for Animal Farm and Nineteen Eighty-Four."),
            ("Frank Herbert", 1920, "American science fiction author best known for the epic Dune series."),
            ("Isaac Asimov", 1920, "Prolific author and biochemist famed for the Foundation series and laws of robotics."),
            ("Aldous Huxley", 1894, "English writer and philosopher known for Brave New World and visionary essays."),
            ("Mary Shelley", 1797, "English novelist who pioneered modern science fiction with Frankenstein."),
            ("Marcus Aurelius", 121, "Roman emperor and Stoic philosopher who authored Meditations."),
            ("F. Scott Fitzgerald", 1896, "American novelist capturing the Jazz Age in The Great Gatsby."),
            ("Arthur Conan Doyle", 1859, "British writer celebrated for creating detective Sherlock Holmes."),
            ("Daniel Kahneman", 1934, "Nobel laureate psychologist renowned for behavioral economics and cognitive heuristics."),
            ("Philip K. Dick", 1928, "Influential science fiction novelist exploring altered realities, identity, and androids."),
        ]
        authors = {}
        for name, birth, bio in authors_data:
            a, _ = Author.objects.get_or_create(name=name, defaults={'birth_year': birth, 'bio': bio})
            authors[name] = a

        # 6. Books
        books_data = [
            {
                "title": "1984",
                "subtitle": "A Novel of Totalitarian Surveillance",
                "authors": [authors["George Orwell"]],
                "genres": [genres["Dystopian"], genres["Classic Literature"]],
                "publisher": publishers["Penguin Classics"],
                "year": 1949,
                "isbn": "9780451524935",
                "page_count": 328,
                "cover_url": "https://covers.openlibrary.org/b/id/8575708-L.jpg",
                "is_featured": True,
                "is_trending": True,
                "average_rating": 4.80,
                "ratings_count": 42,
                "description": "Winston Smith lives in a dystopian London ruled by the totalitarian Party and its omnipresent leader, Big Brother. A haunting masterpiece on surveillance, language, truth, and rebellion.",
                "sample_extract": "It was a bright cold day in April, and the clocks were striking thirteen. Winston Smith, his chin nuzzled into his breast in an effort to escape the vile wind, slipped quickly through the glass doors of Victory Mansions, though not quickly enough to prevent a swirl of gritty dust from entering along with him.\n\nThe hallway smelt of boiled cabbage and old rag mats. At one end of it a coloured poster, too large for indoor display, had been tacked to the wall. It depicted simply an enormous face, more than a metre wide: the face of a man of about forty-five, with a heavy black moustache and ruggedly handsome features. Winston made for the stairs. It was no use trying the lift. Even at the best of times it was seldom working, and at present the electric current was cut off during daylight hours.",
                "text_content": "Chapter 1: The clocks were striking thirteen. The Ministry of Truth—Minitrue, in Newspeak—was startlingly different from any other object in sight. It was an enormous pyramidal structure of glittering white concrete, soaring up, terrace after terrace, 300 metres into the air.\n\nFrom where Winston stood it was just possible to read, picked out on its white face in elegant lettering, the three slogans of the Party:\nWAR IS PEACE\nFREEDOM IS SLAVERY\nIGNORANCE IS STRENGTH."
            },
            {
                "title": "Dune",
                "subtitle": "Book One of the Dune Chronicles",
                "authors": [authors["Frank Herbert"]],
                "genres": [genres["Science Fiction"], genres["Philosophy"]],
                "publisher": publishers["Tor Books"],
                "year": 1965,
                "isbn": "9780441013593",
                "page_count": 688,
                "cover_url": "https://covers.openlibrary.org/b/id/12574169-L.jpg",
                "is_featured": True,
                "is_trending": True,
                "average_rating": 4.90,
                "ratings_count": 55,
                "description": "Set on the desert planet Arrakis, Dune is the story of the boy Paul Atreides, heir to a noble family tasked with ruling an inhospitable world where the only thing of value is the 'spice' melange.",
                "sample_extract": "A beginning is the time for taking the most delicate care that the balances are correct. This every sister of the Bene Gesserit knows. To begin your study of the life of Muad'Dib, then, take care that you first place him in his time: born in the 57th year of the Padishah Emperor, Shaddam IV.\n\nIn the week before their departure to Arrakis, when all the final scurrying hurry had reached a nearly unbearable press, an old crone came to visit the mother of the boy, Paul.",
                "text_content": "Paul sensed his mother waiting outside the door. He could feel her tension. 'Fear is the mind-killer,' he whispered to himself. 'Fear is the little-death that brings total obliteration. I will face my fear. I will permit it to pass over me and through me.'"
            },
            {
                "title": "Foundation",
                "subtitle": "The Epic Galactic Empire Saga",
                "authors": [authors["Isaac Asimov"]],
                "genres": [genres["Science Fiction"], genres["Technology & AI"]],
                "publisher": publishers["HarperCollins"],
                "year": 1951,
                "isbn": "9780553293357",
                "page_count": 255,
                "cover_url": "https://covers.openlibrary.org/b/id/8315182-L.jpg",
                "is_featured": True,
                "is_trending": False,
                "average_rating": 4.75,
                "ratings_count": 38,
                "description": "For twelve thousand years the Galactic Empire has ruled supreme. Now it is dying. Only Hari Seldon, creator of the revolutionary science of psychohistory, can see into the future.",
                "sample_extract": "Hari Seldon was the man who foresaw the fall of the Galactic Empire. The Commission of Public Safety did not believe him, or rather, they believed him too well and feared the panic that his mathematical predictions would induce across twenty-five million inhabited worlds.",
                "text_content": "Psychohistory was the quintessence of sociological mathematics. It could not predict the action of an individual, but across quadrillions of sentient beings, the statistical laws of humanity were as unyielding as the laws of celestial mechanics."
            },
            {
                "title": "Brave New World",
                "subtitle": "A Visionary Dystopian Satire",
                "authors": [authors["Aldous Huxley"]],
                "genres": [genres["Dystopian"], genres["Science Fiction"], genres["Philosophy"]],
                "publisher": publishers["Vintage Books"],
                "year": 1932,
                "isbn": "9780060850524",
                "page_count": 288,
                "cover_url": "https://covers.openlibrary.org/b/id/8759144-L.jpg",
                "is_featured": False,
                "is_trending": True,
                "average_rating": 4.65,
                "ratings_count": 31,
                "description": "Aldous Huxley's profoundly important classic of world literature presents a terrifying vision of a futuristic society conditioned by genetics, consumerism, and state-administered pleasure.",
                "sample_extract": "A squat grey building of only thirty-four storeys. Over the main entrance the words, CENTRAL LONDON HATCHERY AND CONDITIONING CENTRE, and, in a shield, the World State's motto, COMMUNITY, IDENTITY, STABILITY.",
                "text_content": "The enormous room on the ground floor faced towards the north. Cold for all the summer beyond the panes, for all the tropical heat of the room itself, a harsh thin light glared through the windows, hungrily seeking some draped lay figure, some pallid shape of academic goose-flesh."
            },
            {
                "title": "Frankenstein",
                "subtitle": "Or, The Modern Prometheus",
                "authors": [authors["Mary Shelley"]],
                "genres": [genres["Classic Literature"], genres["Science Fiction"]],
                "publisher": publishers["Penguin Classics"],
                "year": 1818,
                "isbn": "9780141439471",
                "page_count": 280,
                "cover_url": "https://covers.openlibrary.org/b/id/8231856-L.jpg",
                "is_featured": False,
                "is_trending": False,
                "average_rating": 4.55,
                "ratings_count": 29,
                "description": "Victor Frankenstein discovers the secret of imparting life to inanimate matter. But when his creation awakens, Victor flees in horror, unleashing a tragic chain of retribution and grief.",
                "sample_extract": "You will rejoice to hear that no disaster has accompanied the commencement of an enterprise which you have regarded with such evil forebodings. I arrived here yesterday, and my first task is to assure my dear sister of my welfare.",
                "text_content": "It was on a dreary night of November that I beheld the accomplishment of my toils. With an anxiety that almost amounted to agony, I collected the instruments of life around me, that I might infuse a spark of being into the lifeless thing that lay at my feet."
            },
            {
                "title": "Meditations",
                "subtitle": "Thoughts of the Stoic Emperor",
                "authors": [authors["Marcus Aurelius"]],
                "genres": [genres["Philosophy"], genres["Psychology"]],
                "publisher": publishers["Oxford University Press"],
                "year": 180,
                "isbn": "9780140449334",
                "page_count": 254,
                "cover_url": "https://covers.openlibrary.org/b/id/8315185-L.jpg",
                "is_featured": True,
                "is_trending": False,
                "average_rating": 4.88,
                "ratings_count": 45,
                "description": "A series of personal spiritual reflections and timeless wisdom by the Roman Emperor Marcus Aurelius, offering enduring guidance on self-discipline, resilience, reason, and duty.",
                "sample_extract": "When you wake up in the morning, tell yourself: The people I deal with today will be meddling, ungrateful, arrogant, dishonest, jealous, and surly. They are like this because they cannot distinguish good from evil.",
                "text_content": "Never let the future disturb you. You will meet it, if you have to, with the same weapons of reason which today arm you against the present. Waste no more time arguing about what a good man should be. Be one."
            },
            {
                "title": "The Great Gatsby",
                "subtitle": "The Classic Tale of the Jazz Age",
                "authors": [authors["F. Scott Fitzgerald"]],
                "genres": [genres["Classic Literature"]],
                "publisher": publishers["HarperCollins"],
                "year": 1925,
                "isbn": "9780743273565",
                "page_count": 180,
                "cover_url": "https://covers.openlibrary.org/b/id/8431872-L.jpg",
                "is_featured": False,
                "is_trending": True,
                "average_rating": 4.60,
                "ratings_count": 33,
                "description": "The quintessential novel of the Jazz Age, recounting the romantic obsession of the mysterious millionaire Jay Gatsby and his tragic longing for the elusive Daisy Buchanan.",
                "sample_extract": "In my younger and more vulnerable years my father gave me some advice that I've been turning over in my mind ever since. 'Whenever you feel like criticizing any one,' he told me, 'just remember that all the people in this world haven't had the advantages that you've had.'",
                "text_content": "Gatsby believed in the green light, the orgastic future that year by year recedes before us. It eluded us then, but that's no matter—tomorrow we will run faster, stretch out our arms farther. . . . And one fine morning— So we beat on, boats against the current, borne back ceaselessly into the past."
            },
            {
                "title": "The Adventures of Sherlock Holmes",
                "subtitle": "Twelve Legendary Cases of 221B Baker Street",
                "authors": [authors["Arthur Conan Doyle"]],
                "genres": [genres["Mystery & Thriller"], genres["Classic Literature"]],
                "publisher": publishers["Penguin Classics"],
                "year": 1892,
                "isbn": "9780141034348",
                "page_count": 307,
                "cover_url": "https://covers.openlibrary.org/b/id/8226178-L.jpg",
                "is_featured": False,
                "is_trending": False,
                "average_rating": 4.70,
                "ratings_count": 27,
                "description": "A collection of twelve masterly detective stories featuring the singular genius Sherlock Holmes and his steadfast chronicler Dr. John Watson navigating Victorian London's darkest crimes.",
                "sample_extract": "To Sherlock Holmes she is always THE woman. I have seldom heard him mention her under any other name. In his eyes she eclipses and predominates the whole of her sex.",
                "text_content": "It is an old maxim of mine that when you have excluded the impossible, whatever remains, however improbable, must be the truth. You see, Watson, but you do not observe. The distinction is perfectly clear."
            },
            {
                "title": "Thinking, Fast and Slow",
                "subtitle": "The Groundbreaking Exploration of Human Judgment",
                "authors": [authors["Daniel Kahneman"]],
                "genres": [genres["Psychology"], genres["Philosophy"]],
                "publisher": publishers["Vintage Books"],
                "year": 2011,
                "isbn": "9780374533557",
                "page_count": 499,
                "cover_url": "https://covers.openlibrary.org/b/id/8315188-L.jpg",
                "is_featured": True,
                "is_trending": True,
                "average_rating": 4.85,
                "ratings_count": 40,
                "description": "In this international bestseller, Daniel Kahneman takes us on a groundbreaking tour of the mind and explains the two systems that drive the way we think: System 1 (fast, intuitive) and System 2 (slow, deliberative).",
                "sample_extract": "To observe your mind in automatic mode, look at the image below. Your experience as you looked at the woman's face combined seamlessly what we normally call seeing and intuitive thinking.",
                "text_content": "A reliable way to make people believe in falsehoods is frequent repetition, because familiarity is not easily distinguished from truth. Authoritarian institutions and marketers have always known this fact."
            },
            {
                "title": "Do Androids Dream of Electric Sheep?",
                "subtitle": "The Cyberpunk Inspiration for Blade Runner",
                "authors": [authors["Philip K. Dick"]],
                "genres": [genres["Science Fiction"], genres["Dystopian"], genres["Philosophy"]],
                "publisher": publishers["HarperCollins"],
                "year": 1968,
                "isbn": "9780345404473",
                "page_count": 240,
                "cover_url": "https://covers.openlibrary.org/b/id/8231859-L.jpg",
                "is_featured": False,
                "is_trending": True,
                "average_rating": 4.68,
                "ratings_count": 24,
                "description": "By 2021, the World War has killed millions, driving entire species into extinction. Bounty hunter Rick Deckard is tasked with retiring rogue Nexus-6 androids posing as humans in San Francisco.",
                "sample_extract": "A merry little surge of electricity piped by automatic alarm from the bedside mood organ had awakened Rick Deckard. He was surprised to find it was six-fifteen; he turned off the alarm and stretched out in bed.",
                "text_content": "'You will be required to do wrong no matter where you go,' the old man said. 'It is the basic condition of life, to be required to violate your own identity. At some time, every creature which lives must do so.'"
            }
        ]

        books = []
        for b_dict in books_data:
            book, _ = Book.objects.get_or_create(
                title=b_dict["title"],
                defaults={
                    "subtitle": b_dict.get("subtitle", ""),
                    "publisher": b_dict.get("publisher"),
                    "publication_year": b_dict["year"],
                    "isbn": b_dict["isbn"],
                    "page_count": b_dict["page_count"],
                    "cover_url": b_dict["cover_url"],
                    "is_featured": b_dict["is_featured"],
                    "is_trending": b_dict["is_trending"],
                    "average_rating": b_dict["average_rating"],
                    "ratings_count": b_dict["ratings_count"],
                    "description": b_dict["description"],
                    "sample_extract": b_dict["sample_extract"],
                    "text_content": b_dict["text_content"],
                }
            )
            book.authors.set(b_dict["authors"])
            book.genres.set(b_dict["genres"])
            books.append(book)

        # 7. Reviews and Ratings
        reviews_samples = [
            (users["alice"], books[0], 5, "Unquestionably Prescient", "The psychological depth of the Party's control mechanisms feels eerily relevant in the era of automated algorithmic surveillance."),
            (users["bob"], books[1], 5, "A Sci-Fi Epic of Mythic Proportions", "Frank Herbert synthesized ecology, religion, and galactic politics into a narrative that never loses its grandeur."),
            (users["charlie"], books[0], 4, "Chilling and unforgettable", "The atmosphere in Victory Mansions is suffocating and brilliantly depicted."),
            (users["diana"], books[5], 5, "Life-Altering Practical Philosophy", "Marcus Aurelius reminds us that peace of mind is an internal fortress, not an external circumstance."),
            (users["elena"], books[2], 5, "Psychohistory is Genius", "Asimov's concept of macro-historical trends driven by statistical science remains one of fiction's greatest premises."),
            (users["alice"], books[9], 4, "Deeply Philosophical Cyberpunk", "Questions what makes humans distinct from machines in ways that keep you awake at night."),
            (users["bob"], books[6], 4, "Lyrical and Tragic", "Fitzgerald's prose flows like champagne with an undercurrent of melancholy."),
            (users["charlie"], books[7], 5, "Peak Deductive Mystery", "The Bohemian scandal and the Red-Headed League are peak Victorian detective fiction."),
            (users["diana"], books[8], 5, "Essential Cognitive Psychology", "Kahneman systematically dismantles the myth of rational decision making with crystal clear research."),
        ]

        for u, b, rating, title, content in reviews_samples:
            Review.objects.get_or_create(
                user=u,
                book=b,
                defaults={
                    'rating': rating,
                    'title': title,
                    'content': content,
                    'likes_count': random.randint(3, 18),
                    'is_approved': True
                }
            )

        # 8. User Reading Progress & Favorites
        Favorite.objects.get_or_create(user=users['alice'], book=books[0])
        Favorite.objects.get_or_create(user=users['alice'], book=books[1])
        Favorite.objects.get_or_create(user=users['bob'], book=books[5])
        Favorite.objects.get_or_create(user=users['charlie'], book=books[7])
        Favorite.objects.get_or_create(user=users['diana'], book=books[8])

        ReadingProgress.objects.get_or_create(
            user=users['alice'],
            book=books[1],
            defaults={'status': 'currently_reading', 'current_page': 285, 'total_pages': books[1].page_count}
        )
        ReadingProgress.objects.get_or_create(
            user=users['alice'],
            book=books[0],
            defaults={'status': 'completed', 'current_page': books[0].page_count, 'total_pages': books[0].page_count, 'completed_at': timezone.now() - timedelta(days=2)}
        )
        ReadingProgress.objects.get_or_create(
            user=users['bob'],
            book=books[5],
            defaults={'status': 'completed', 'current_page': books[5].page_count, 'total_pages': books[5].page_count, 'completed_at': timezone.now() - timedelta(days=5)}
        )

        # 9. Bookmarks
        Bookmark.objects.get_or_create(
            user=users['alice'],
            book=books[1],
            defaults={'location': 'Chapter 14, Page 285', 'note': 'Bene Gesserit litany against fear.', 'color': '#2563EB'}
        )

        # 10. Community Discussions
        disc, _ = Discussion.objects.get_or_create(
            book=books[1],
            user=users['alice'],
            defaults={'title': 'The Ecological Parallels of Arrakis in 2026', 'content': 'How does Frank Herbert’s portrayal of resource scarcity mirror our current climate and energy dialogues?'}
        )
        DiscussionComment.objects.get_or_create(
            discussion=disc,
            user=users['bob'],
            defaults={'content': 'Herbert was heavily influenced by dune stabilization studies in Oregon. The ecological foresight is astonishing.'}
        )

        # 11. Notifications
        Notification.objects.get_or_create(
            user=users['alice'],
            title='AI Recommendations Refreshed',
            defaults={
                'message': 'Based on your recent reading of Dune, we have synthesized 4 new speculative sci-fi titles.',
                'notification_type': 'recommendation',
                'link': '/recommendations/'
            }
        )
        Notification.objects.get_or_create(
            user=users['alice'],
            title='Reading Streak Milestone: 7 Days!',
            defaults={
                'message': 'Keep going! You are 58% towards your annual reading challenge.',
                'notification_type': 'reading_goal',
                'link': '/dashboard/'
            }
        )

        # 12. Build Ontology & Train Recommendation Models
        self.stdout.write(self.style.NOTICE("Generating semantic OWL ontology from database..."))
        onto_res = generate_bookverse_ontology()
        self.stdout.write(self.style.SUCCESS(f"Ontology generated: {onto_res['triples_count']} triples."))

        self.stdout.write(self.style.NOTICE("Training ML Recommendation Models..."))
        engine = RecommendationEngine()
        train_res = engine.train_models()
        self.stdout.write(self.style.SUCCESS(f"Trained models: {train_res.get('status')} (Version {train_res.get('version')})"))

        # Pre-generate recommendations for demo users
        for u in users.values():
            engine.generate_recommendations_for_user(u, top_k=6)

        self.stdout.write(self.style.SUCCESS("\nBookVerse AI seeding completed successfully!"))
        self.stdout.write(self.style.SUCCESS("Admin login: admin / admin123"))
        self.stdout.write(self.style.SUCCESS("Demo users: alice, bob, charlie, diana, elena / password: password123"))
