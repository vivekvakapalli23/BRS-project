import uuid
from django.db import models
from django.contrib.auth.models import User
from django.utils.text import slugify
from django.urls import reverse

class Author(models.Model):
    name = models.CharField(max_length=255, db_index=True)
    slug = models.SlugField(max_length=280, unique=True, blank=True)
    bio = models.TextField(blank=True)
    birth_year = models.IntegerField(null=True, blank=True)
    photo = models.ImageField(upload_to='authors/', blank=True, null=True)
    photo_url = models.URLField(blank=True, max_length=500)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['name']
        indexes = [
            models.Index(fields=['name']),
            models.Index(fields=['slug']),
        ]

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.name) or "author"
            slug = base_slug
            counter = 1
            while Author.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug = f"{base_slug}-{counter}"
                counter += 1
            self.slug = slug
        super().save(*args, **kwargs)

    @property
    def get_photo_url(self):
        if self.photo:
            return self.photo.url
        if self.photo_url:
            return self.photo_url
        return f"https://ui-avatars.com/api/?name={self.name}&background=1E3A8A&color=ffffff"


class Genre(models.Model):
    name = models.CharField(max_length=100, unique=True, db_index=True)
    slug = models.SlugField(max_length=120, unique=True, blank=True)
    description = models.TextField(blank=True)
    icon = models.CharField(max_length=50, default='bi-book', help_text="Bootstrap icon class")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name) or "genre"
        super().save(*args, **kwargs)


class Subject(models.Model):
    name = models.CharField(max_length=120, unique=True, db_index=True)
    slug = models.SlugField(max_length=140, unique=True, blank=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name) or "subject"
        super().save(*args, **kwargs)


class Publisher(models.Model):
    name = models.CharField(max_length=255, unique=True, db_index=True)
    location = models.CharField(max_length=255, blank=True)
    website = models.URLField(blank=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name


class Book(models.Model):
    title = models.CharField(max_length=300, db_index=True)
    subtitle = models.CharField(max_length=300, blank=True)
    slug = models.SlugField(max_length=320, unique=True, blank=True)
    authors = models.ManyToManyField(Author, related_name='books')
    genres = models.ManyToManyField(Genre, related_name='books')
    subjects = models.ManyToManyField(Subject, blank=True, related_name='books')
    publisher = models.ForeignKey(Publisher, on_delete=models.SET_NULL, null=True, blank=True, related_name='books')
    publication_year = models.IntegerField(null=True, blank=True, db_index=True)
    isbn = models.CharField(max_length=13, blank=True, db_index=True)
    isbn13 = models.CharField(max_length=17, blank=True)
    language = models.CharField(max_length=50, default='English', db_index=True)
    description = models.TextField(blank=True)
    page_count = models.PositiveIntegerField(default=250)
    
    # Covers
    cover_image = models.ImageField(upload_to='book_covers/', blank=True, null=True)
    cover_url = models.URLField(blank=True, max_length=500)

    # Metrics
    average_rating = models.DecimalField(max_digits=3, decimal_places=2, default=0.00, db_index=True)
    ratings_count = models.PositiveIntegerField(default=0)
    view_count = models.PositiveIntegerField(default=0)
    is_featured = models.BooleanField(default=False, db_index=True)
    is_trending = models.BooleanField(default=False, db_index=True)
    
    # Ebook reader authorized files
    open_library_id = models.CharField(max_length=50, blank=True)
    pdf_file = models.FileField(upload_to='ebooks/pdf/', blank=True, null=True)
    epub_file = models.FileField(upload_to='ebooks/epub/', blank=True, null=True)
    text_content = models.TextField(blank=True, help_text="Built-in public domain text extract for online reading")
    sample_extract = models.TextField(blank=True, help_text="Sample introductory chapter for reader")
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-average_rating', '-ratings_count', '-created_at']
        indexes = [
            models.Index(fields=['title']),
            models.Index(fields=['publication_year']),
            models.Index(fields=['average_rating']),
            models.Index(fields=['is_featured']),
            models.Index(fields=['is_trending']),
        ]

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            base = slugify(self.title) or f"book-{uuid.uuid4().hex[:8]}"
            slug = base
            counter = 1
            while Book.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug = f"{base}-{counter}"
                counter += 1
            self.slug = slug
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse('books:book_detail', kwargs={'slug': self.slug})

    @property
    def get_cover_url(self):
        if self.cover_image:
            return self.cover_image.url
        if self.cover_url:
            return self.cover_url
        return f"https://placehold.co/300x450/1E3A8A/FFFFFF/png?text={self.title[:20]}"

    @property
    def primary_author(self):
        first = self.authors.first()
        return first.name if first else "Unknown Author"

    @property
    def authors_display(self):
        return ", ".join([a.name for a in self.authors.all()]) or "Unknown Author"

    @property
    def genres_display(self):
        return ", ".join([g.name for g in self.genres.all()])

    def update_rating_metrics(self):
        from community.models import Review
        reviews = Review.objects.filter(book=self, is_approved=True)
        count = reviews.count()
        if count > 0:
            avg = reviews.aggregate(models.Avg('rating'))['rating__avg']
            self.average_rating = round(avg, 2)
            self.ratings_count = count
        else:
            self.average_rating = 0.00
            self.ratings_count = 0
        self.save(update_fields=['average_rating', 'ratings_count'])


class Favorite(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='favorites')
    book = models.ForeignKey(Book, on_delete=models.CASCADE, related_name='favorited_by')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'book')
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.user.username} favorited {self.book.title}"


class ReadingProgress(models.Model):
    STATUS_CHOICES = [
        ('want_to_read', 'Want to Read'),
        ('currently_reading', 'Currently Reading'),
        ('completed', 'Completed'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reading_progress')
    book = models.ForeignKey(Book, on_delete=models.CASCADE, related_name='reader_progress')
    status = models.CharField(max_length=25, choices=STATUS_CHOICES, default='want_to_read', db_index=True)
    current_page = models.PositiveIntegerField(default=1)
    total_pages = models.PositiveIntegerField(default=100)
    progress_percentage = models.DecimalField(max_digits=5, decimal_places=2, default=0.00)
    last_location = models.CharField(max_length=255, blank=True, help_text="CFI for epub or page for pdf")
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('user', 'book')
        indexes = [
            models.Index(fields=['user', 'status']),
        ]

    def __str__(self):
        return f"{self.user.username} - {self.book.title} ({self.get_status_display()})"

    def save(self, *args, **kwargs):
        if self.total_pages > 0 and self.current_page > 0:
            pct = min(100.0, (self.current_page / self.total_pages) * 100)
            self.progress_percentage = round(pct, 2)
            if self.progress_percentage >= 100.0 and self.status != 'completed':
                self.status = 'completed'
                from django.utils import timezone
                self.completed_at = timezone.now()
        super().save(*args, **kwargs)


class ReadingList(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reading_lists')
    name = models.CharField(max_length=150)
    description = models.TextField(blank=True)
    is_public = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.name} by {self.user.username}"


class ReadingListItem(models.Model):
    reading_list = models.ForeignKey(ReadingList, on_delete=models.CASCADE, related_name='items')
    book = models.ForeignKey(Book, on_delete=models.CASCADE, related_name='in_lists')
    order = models.PositiveIntegerField(default=0)
    added_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('reading_list', 'book')
        ordering = ['order', '-added_at']

    def __str__(self):
        return f"{self.book.title} in {self.reading_list.name}"


class Bookmark(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='bookmarks')
    book = models.ForeignKey(Book, on_delete=models.CASCADE, related_name='bookmarks')
    location = models.CharField(max_length=255, help_text="Page number or EPUB CFI")
    note = models.TextField(blank=True)
    color = models.CharField(max_length=20, default='#2563EB')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Bookmark at {self.location} for {self.book.title}"


class ReadingGoal(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reading_goals')
    title = models.CharField(max_length=150, default="Annual Reading Challenge")
    target_books = models.PositiveIntegerField(default=12)
    year = models.PositiveIntegerField(default=2026)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'year')

    def __str__(self):
        return f"{self.user.username}'s {self.year} Goal ({self.target_books} books)"

    @property
    def completed_count(self):
        return ReadingProgress.objects.filter(
            user=self.user,
            status='completed',
            completed_at__year=self.year
        ).count()

    @property
    def percentage_completed(self):
        if self.target_books <= 0:
            return 0
        return min(100, int((self.completed_count / self.target_books) * 100))
