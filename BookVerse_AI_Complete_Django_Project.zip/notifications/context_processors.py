from .models import Notification

def unread_notifications_count(request):
    if request.user.is_authenticated:
        count = Notification.objects.filter(user=request.user, is_read=False).count()
        latest = Notification.objects.filter(user=request.user).order_by('-created_at')[:5]
        return {
            'unread_notifications_count': count,
            'recent_notifications': latest,
        }
    return {
        'unread_notifications_count': 0,
        'recent_notifications': [],
    }
